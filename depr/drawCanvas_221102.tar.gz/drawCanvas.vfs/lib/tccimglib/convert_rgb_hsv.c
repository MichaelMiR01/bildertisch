/*https://stackoverflow.com/questions/3018313/algorithm-to-convert-rgb-to-hsv-and-hsv-to-rgb-in-range-0-255-for-both*/
/* float version*/
typedef struct {
    double r;       // a fraction between 0 and 1
    double g;       // a fraction between 0 and 1
    double b;       // a fraction between 0 and 1
} rgb;

typedef struct {
    double h;       // angle in degrees
    double s;       // a fraction between 0 and 1
    double v;       // a fraction between 0 and 1
} hsv;

static hsv   rgb2hsv(rgb in);
static rgb   hsv2rgb(hsv in);

hsv rgb2hsv_f(rgb in)
{
    hsv         out;
    double      min, max, delta;

    min = in.r < in.g ? in.r : in.g;
    min = min  < in.b ? min  : in.b;

    max = in.r > in.g ? in.r : in.g;
    max = max  > in.b ? max  : in.b;

    out.v = max;                                // v
    delta = max - min;
    if (delta < 0.00001)
    {
        out.s = 0;
        out.h = 0; // undefined, maybe nan?
        return out;
    }
    if( max > 0.0 ) { // NOTE: if Max is == 0, this divide would cause a crash
        out.s = (delta / max);                  // s
    } else {
        // if max is 0, then r = g = b = 0              
        // s = 0, h is undefined
        out.s = 0.0;
        out.h = NAN;                            // its now undefined
        return out;
    }
    if( in.r >= max )                           // > is bogus, just keeps compilor happy
        out.h = ( in.g - in.b ) / delta;        // between yellow & magenta
    else
    if( in.g >= max )
        out.h = 2.0 + ( in.b - in.r ) / delta;  // between cyan & yellow
    else
        out.h = 4.0 + ( in.r - in.g ) / delta;  // between magenta & cyan

    out.h *= 60.0;                              // degrees

    if( out.h < 0.0 )
        out.h += 360.0;

    return out;
}


rgb hsv2rgb_f(hsv in)
{
    double      hh, p, q, t, ff;
    long        i;
    rgb         out;

    if(in.s <= 0.0) {       // < is bogus, just shuts up warnings
        out.r = in.v;
        out.g = in.v;
        out.b = in.v;
        return out;
    }
    hh = in.h;
    if(hh >= 360.0) hh = 0.0;
    hh /= 60.0;
    i = (long)hh;
    ff = hh - i;
    p = in.v * (1.0 - in.s);
    q = in.v * (1.0 - (in.s * ff));
    t = in.v * (1.0 - (in.s * (1.0 - ff)));

    switch(i) {
    case 0:
        out.r = in.v;
        out.g = t;
        out.b = p;
        break;
    case 1:
        out.r = q;
        out.g = in.v;
        out.b = p;
        break;
    case 2:
        out.r = p;
        out.g = in.v;
        out.b = t;
        break;

    case 3:
        out.r = p;
        out.g = q;
        out.b = in.v;
        break;
    case 4:
        out.r = t;
        out.g = p;
        out.b = in.v;
        break;
    case 5:
    default:
        out.r = in.v;
        out.g = p;
        out.b = q;
        break;
    }
    return out;     
}

/* char version 0...255 */

typedef struct RgbColor
{
    unsigned char r;
    unsigned char g;
    unsigned char b;
} RgbColor;

typedef struct HsvColor
{
    unsigned char h;
    unsigned char s;
    unsigned char v;
} HsvColor;

RgbColor HsvToRgb(HsvColor hsv)
{
    RgbColor rgb;
    unsigned char region, remainder, p, q, t;

    if (hsv.s == 0)
    {
        rgb.r = hsv.v;
        rgb.g = hsv.v;
        rgb.b = hsv.v;
        return rgb;
    }

    region = hsv.h / 43;
    remainder = (hsv.h - (region * 43)) * 6; 

    p = (hsv.v * (255 - hsv.s)) >> 8;
    q = (hsv.v * (255 - ((hsv.s * remainder) >> 8))) >> 8;
    t = (hsv.v * (255 - ((hsv.s * (255 - remainder)) >> 8))) >> 8;

    switch (region)
    {
        case 0:
            rgb.r = hsv.v; rgb.g = t; rgb.b = p;
            break;
        case 1:
            rgb.r = q; rgb.g = hsv.v; rgb.b = p;
            break;
        case 2:
            rgb.r = p; rgb.g = hsv.v; rgb.b = t;
            break;
        case 3:
            rgb.r = p; rgb.g = q; rgb.b = hsv.v;
            break;
        case 4:
            rgb.r = t; rgb.g = p; rgb.b = hsv.v;
            break;
        default:
            rgb.r = hsv.v; rgb.g = p; rgb.b = q;
            break;
    }

    return rgb;
}

HsvColor RgbToHsv(RgbColor rgb)
{
    HsvColor hsv;
    unsigned char rgbMin, rgbMax;

    rgbMin = rgb.r < rgb.g ? (rgb.r < rgb.b ? rgb.r : rgb.b) : (rgb.g < rgb.b ? rgb.g : rgb.b);
    rgbMax = rgb.r > rgb.g ? (rgb.r > rgb.b ? rgb.r : rgb.b) : (rgb.g > rgb.b ? rgb.g : rgb.b);

    hsv.v = rgbMax;
    if (hsv.v == 0)
    {
        hsv.h = 0;
        hsv.s = 0;
        return hsv;
    }

    hsv.s = 255 * long(rgbMax - rgbMin) / hsv.v;
    if (hsv.s == 0)
    {
        hsv.h = 0;
        return hsv;
    }

    if (rgbMax == rgb.r)
        hsv.h = 0 + 43 * (rgb.g - rgb.b) / (rgbMax - rgbMin);
    else if (rgbMax == rgb.g)
        hsv.h = 85 + 43 * (rgb.b - rgb.r) / (rgbMax - rgbMin);
    else
        hsv.h = 171 + 43 * (rgb.r - rgb.g) / (rgbMax - rgbMin);

    return hsv;
}
/* -- further versions */
#include <math.h>

typedef struct {
    double r;       //  [0, 1]
    double g;       //  [0, 1]
    double b;       //  [0, 1]
} rgb;

typedef struct {
    double h;       //  [0, 360]
    double s;       //  [0, 1]
    double v;       //  [0, 1]
} hsv;

rgb hsv2rgb(hsv HSV)
{
    rgb RGB;
    double H = HSV.h, S = HSV.s, V = HSV.v,
            P, Q, T,
            fract;

    (H == 360.)?(H = 0.):(H /= 60.);
    fract = H - floor(H);

    P = V*(1. - S);
    Q = V*(1. - S*fract);
    T = V*(1. - S*(1. - fract));

    if      (0. <= H && H < 1.)
        RGB = (rgb){.r = V, .g = T, .b = P};
    else if (1. <= H && H < 2.)
        RGB = (rgb){.r = Q, .g = V, .b = P};
    else if (2. <= H && H < 3.)
        RGB = (rgb){.r = P, .g = V, .b = T};
    else if (3. <= H && H < 4.)
        RGB = (rgb){.r = P, .g = Q, .b = V};
    else if (4. <= H && H < 5.)
        RGB = (rgb){.r = T, .g = P, .b = V};
    else if (5. <= H && H < 6.)
        RGB = (rgb){.r = V, .g = P, .b = Q};
    else
        RGB = (rgb){.r = 0., .g = 0., .b = 0.};

    return RGB;
}

/* --- */
typedef struct RgbColor
{
    unsigned char r;
    unsigned char g;
    unsigned char b;
} RgbColor;

typedef struct HsvColor
{
    unsigned char h;
    unsigned char s;
    unsigned char v;
} HsvColor;

RgbColor HsvToRgb(HsvColor hsv)
{
    RgbColor rgb;
    unsigned char region, p, q, t;
    unsigned int h, s, v, remainder;

    if (hsv.s == 0)
    {
        rgb.r = hsv.v;
        rgb.g = hsv.v;
        rgb.b = hsv.v;
        return rgb;
    }

    // converting to 16 bit to prevent overflow
    h = hsv.h;
    s = hsv.s;
    v = hsv.v;

    region = h / 43;
    remainder = (h - (region * 43)) * 6; 

    p = (v * (255 - s)) >> 8;
    q = (v * (255 - ((s * remainder) >> 8))) >> 8;
    t = (v * (255 - ((s * (255 - remainder)) >> 8))) >> 8;

    switch (region)
    {
        case 0:
            rgb.r = v;
            rgb.g = t;
            rgb.b = p;
            break;
        case 1:
            rgb.r = q;
            rgb.g = v;
            rgb.b = p;
            break;
        case 2:
            rgb.r = p;
            rgb.g = v;
            rgb.b = t;
            break;
        case 3:
            rgb.r = p;
            rgb.g = q;
            rgb.b = v;
            break;
        case 4:
            rgb.r = t;
            rgb.g = p;
            rgb.b = v;
            break;
        default:
            rgb.r = v;
            rgb.g = p;
            rgb.b = q;
            break;
    }

    return rgb;
}

HsvColor RgbToHsv(RgbColor rgb)
{
    HsvColor hsv;
    unsigned char rgbMin, rgbMax;

    rgbMin = rgb.r < rgb.g ? (rgb.r < rgb.b ? rgb.r : rgb.b) : (rgb.g < rgb.b ? rgb.g : rgb.b);
    rgbMax = rgb.r > rgb.g ? (rgb.r > rgb.b ? rgb.r : rgb.b) : (rgb.g > rgb.b ? rgb.g : rgb.b);

    hsv.v = rgbMax;
    if (hsv.v == 0)
    {
        hsv.h = 0;
        hsv.s = 0;
        return hsv;
    }

    hsv.s = 255 * ((long)(rgbMax - rgbMin)) / hsv.v;
    if (hsv.s == 0)
    {
        hsv.h = 0;
        return hsv;
    }

    if (rgbMax == rgb.r)
        hsv.h = 0 + 43 * (rgb.g - rgb.b) / (rgbMax - rgbMin);
    else if (rgbMax == rgb.g)
        hsv.h = 85 + 43 * (rgb.b - rgb.r) / (rgbMax - rgbMin);
    else
        hsv.h = 171 + 43 * (rgb.r - rgb.g) / (rgbMax - rgbMin);

    return hsv;
}

/*  and more from https://www.pocketmagic.net/enhance-saturation-in-images-programatically/ */
void convertRGBToHSL(l_int32 rval,l_int32 gval,l_int32 bval,
	l_int32 *hval, l_int32 *sval, l_int32 *lval) {
	l_float32 r, g, b, h, s, l; //this function works with floats between 0 and 1
	r = rval / 255.0;
	g = gval / 255.0;
	b = bval / 255.0;
	//Then, minColor and maxColor are defined. Mincolor is the value of the color component with 
	// the smallest value, while maxColor is the value of the color component with the largest value. 
	// These two variables are needed because the Lightness is defined as (minColor + maxColor) / 2.
	float maxColor = MAX(r, MAX(g, b));
	float minColor = MIN(r, MIN(g, b));
	//If minColor equals maxColor, we know that R=G=B and thus the color is a shade of gray. 
	// This is a trivial case, hue can be set to anything, saturation has to be set to 0 because 
	// only then it's a shade of gray, and lightness is set to R=G=B, the shade of the gray.
	//R == G == B, so it's a shade of gray
	if((r == g)&&(g == b)) {
		h = 0.0; //it doesn't matter what value it has
		s = 0.0;
		l = r; //doesn't matter if you pick r, g, or b
	}
	// If minColor is not equal to maxColor, we have a real color instead of a shade of gray, 
	// so more calculations are needed:
	// Lightness (l) is now set to it's definition of (minColor + maxColor)/2.
	// Saturation (s) is then calculated with a different formula depending if light is in the first 
	// half of the second half. This is because the HSL model can be represented as a double cone, the 
	// first cone has a black tip and corresponds to the first half of lightness values, the second cone 
	// has a white tip and contains the second half of lightness values.
	// Hue (h) is calculated with a different formula depending on which of the 3 color components is 
	// the dominating one, and then normalized to a number between 0 and 1.
	else {
		l_float32 d = maxColor - minColor;
		l = (minColor + maxColor) / 2;
		if(l < 0.5) s = d / (maxColor + minColor);
		else s = d / (2.0 - maxColor - minColor);
		if(r == maxColor) h = (g - b) / (maxColor - minColor);
		else if(g == maxColor) h = 2.0 + (b - r) / (maxColor - minColor);
		else h = 4.0 + (r - g) / (maxColor - minColor);
		h /= 6; //to bring it to a number between 0 and 1
		if(h < 0) h ++;
	}
	//Finally, H, S and L are calculated out of h,s and l as integers between 0..360 / 0 and 255 and 
	// "returned"  as the result. Returned, because H, S and L were passed by reference to the function.
	*hval = int(h * 360.0);
	*sval = int(s * 255.0);
	*lval = int(l * 255.0);
}

void convertHSLToRGB(l_int32 hval, l_int32 sval, l_int32 lval, 
	l_int32 *rval, l_int32 *gval, l_int32 *bval) {
	float r, g, b, h, s, l; //this function works with floats between 0 and 1
	float temp1, temp2, tempr, tempg, tempb;
	h = (hval % 260) / 360.0;
	s = sval / 256.0;
	l = lval / 256.0;
	//Then follows a trivial case: if the saturation is 0, the color will be a grayscale color, 
	// and the calculation is then very simple: r, g and b are all set to the lightness.
	//If saturation is 0, the color is a shade of gray
	if(s == 0){
		r = l;
		g = l;
		b = l;
	}
	//If the saturation is higher than 0, more calculations are needed again. red, green and blue 
	// are calculated with the formulas defined in the code.
	//If saturation > 0, more complex calculations are needed
	else {
		//Set the temporary values
		if(l < 0.5) temp2 = l * (1 + s);
		else
		temp2 = (l + s) - (l * s);
		temp1 = 2 * l - temp2;

		tempr = h + 1.0 / 3.0;
		if(tempr > 1) tempr--;
		tempg = h;
		tempb = h - 1.0 / 3.0;
		if(tempb < 0) tempb++;

		//Red
		if(tempr < 1.0 / 6.0) r = temp1 + (temp2 - temp1) * 6.0 * tempr;
		else if(tempr < 0.5) r = temp2;
		else if(tempr < 2.0 / 3.0) r = temp1 + (temp2 - temp1) * ((2.0 / 3.0) - tempr) * 6.0;
		else r = temp1;

		//Green
		if(tempg < 1.0 / 6.0) g = temp1 + (temp2 - temp1) * 6.0 * tempg;
		else if(tempg < 0.5) g = temp2;
		else if(tempg < 2.0 / 3.0) g = temp1 + (temp2 - temp1) * ((2.0 / 3.0) - tempg) * 6.0;
		else g = temp1;

		//Blue
		if(tempb < 1.0 / 6.0) b = temp1 + (temp2 - temp1) * 6.0 * tempb;
		else if(tempb < 0.5) b = temp2;
		else if(tempb < 2.0 / 3.0) b = temp1 + (temp2 - temp1) * ((2.0 / 3.0) - tempb) * 6.0;
		else b = temp1;
	}
	//And finally, the results are returned as integers between 0 and 255.
	*rval = int(r * 255.0);
	*gval = int(g * 255.0);
	*bval = int(b * 255.0);
}

/* and a basic saturation algorithm (defunct, missing some routines like composeRGBPixel...) but as a concept :-)*/

void pixSat(PIX *pixs, l_float32  fract) {
	// normalize parameters
	if (fract < -1) fract = -1;
	else if (fract > 1) fract = 1;

	l_uint32  *datas, *lines;
	l_int32    i, j, bx, by, bw, bh, w, h, wpls;
	l_int32    rval, gval, bval;
	if (!pixs || pixGetDepth(pixs) != 32)
		return; //not 32bpp
	pixGetDimensions(pixs, &w, &h, NULL);
	datas = pixGetData(pixs);
	wpls = pixGetWpl(pixs);

	for (i = 0; i < h; i++) {
		lines = datas + i * wpls;
		for (j = 0; j < w; j++) {
			extractRGBValues(lines[j], &rval, &gval, &bval);
			l_int32 h, s, l;
			convertRGBToHSL(rval, gval, bval, &h, &s, &l);
			
			if (fract >= 0) {
				// we don't want to saturate unsaturated colors -> we get only defects
				// for unsaturared colors this tends to 0
				float gray_factor = (float)s / 255.0; 
				// how far can we go?
				// if we increase saturation, we have "255-s" space left
				float var_interval = 255 - s; 
				// compute the new saturation
				s = s + fract * var_interval * gray_factor;
			} else {
				// how far can we go?
				// for decrease we have "s" left
				float var_interval = s; 
				s = s + fract * var_interval  ;
			}
			
			convertHSLToRGB(h,s,l, &rval, &gval, &bval);
			composeRGBPixel(rval, gval, bval, lines + j);
		}
	}
}

/* and some solicited javascript code from https://stackoverflow.com/questions/13806483/increase-or-decrease-color-saturation

Here's a quick and dirty way that probably isn't correct in any technical way, but involves less computation than converting to HSV and back (so renders quicker if that matters):

Grayscale is the equivalent of calculating luminosity averaged over the RGB parts of the pixel. We can mix grayness by applying a value weighting to the gray part versus the colored part:

var pixels = context.getImageData(0, 0, canvas.width, canvas.height);
grayscale = function (pixels, value) {
    var d = pixels.data;
    for (var i = 0; i < d.length; i += 4) {
        var r = d[i];
        var g = d[i + 1];
        var b = d[i + 2];
        var gray = 0.2989*r + 0.5870*g + 0.1140*b; //weights from CCIR 601 spec
        d[i] = gray * value + d[i] * (1-value);
        d[i+1] = gray * value + d[i+1] * (1-value);
        d[i+2] = gray * value + d[i+2] * (1-value);
    }
    return pixels;
};

So instead of adding "grayness", we can take it away and add the relevant color back in to "saturate":

saturate = function (pixels, value) {
    var d = pixels.data;
    for (var i = 0; i < d.length; i += 4) {
        var r = d[i]; 
        var g = d[i + 1];
        var b = d[i + 2];
        var gray = 0.2989*r + 0.5870*g + 0.1140*b; //weights from CCIR 601 spec
        d[i] = -gray * value + d[i] * (1+value);
        d[i+1] = -gray * value + d[i+1] * (1+value);
        d[i+2] = -gray * value + d[i+2] * (1+value);
        //normalize over- and under-saturated values
        if(d[i] > 255) d[i] = 255;
        if(d[i+1] > 255) d[i] = 255;
        if(d[i+2] > 255) d[i] = 255;
        if(d[i] < 0) d[i] = 0;
        if(d[i+1] < 0) d[i] = 0;
        if(d[i+2] < 0) d[i] = 0;
    }
    return pixels;
};

Again, disclaimer that this "looks" saturated but probably in no way adheres to the technical definition of "saturation" (whatever that is); I've simply posted this in the hope that it's helpful to passers-by.
*/
