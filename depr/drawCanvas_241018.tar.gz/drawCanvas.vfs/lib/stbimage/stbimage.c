/***************** Automatically Created with TCC4TCL Helper and maybe TSP **********************************/
/* Compiler directives are raw estimates, please adapt to given pathstructure */

/* for gccwin32 use */
/* C:/D/Toolbox/tcl/tcc_0.9.27-bin/gcc/bin/gcc.exe  -s -m32 -D_WIN32 -static-libgcc  -shared -DUSE_TCL_STUBS -O2  -Iinclude -Iinclude/generic -Iinclude/generic/win -Iinclude/xlib -Itsp-package/native/clang/ -I./done/stbimage -I./done/stbimage ./done/stbimage/stbimage.c -o./done/stbimage/stbimage.dll -Llib_win32 -ltclstub86 -ltkstub86 -L./done/stbimage */

/* for tccwin32 use */
/* C:/D/Toolbox/tcl/tcc_0.9.27-bin/tcc.exe  -m32 -D_WIN32  -shared -DUSE_TCL_STUBS -O2  -Iinclude -Iinclude/stdinc -Iinclude/generic -Iinclude/generic/win -Iinclude/xlib -Iwin32 -Iwin32/winapi  -Itsp-package/native/clang/ -I./done/stbimage -I./done/stbimage ./done/stbimage/stbimage.c -o./done/stbimage/stbimage.dll -ltclstub86elf -ltkstub86elf -L./done/stbimage */

/* for gcc use */
/* C:/D/Toolbox/tcl/tcc_0.9.27-bin/gcc/bin/gcc.exe  -s -m32 -D_WIN32 -static-libgcc  -shared -DUSE_TCL_STUBS -O2  -Iinclude -Iinclude/generic -Iinclude/generic/win -Iinclude/xlib -Itsp-package/native/clang/ -I./done/stbimage -I./done/stbimage ./done/stbimage/stbimage.c -o./done/stbimage/stbimage.dll -Llib_win32 -ltclstub86 -ltkstub86 -L./done/stbimage */

/* for tcc use */
/* C:/D/Toolbox/tcl/tcc_0.9.27-bin/tcc.exe  -m32 -D_WIN32  -shared -DUSE_TCL_STUBS -O2  -Iinclude -Iinclude/stdinc -Iinclude/generic -Iinclude/generic/win -Iinclude/xlib -Iwin32 -Iwin32/winapi  -Itsp-package/native/clang/ -I./done/stbimage -I./done/stbimage ./done/stbimage/stbimage.c -o./done/stbimage/stbimage.dll -ltclstub86elf -ltkstub86elf -L./done/stbimage */

/***************** Automatically Created with TCC4TCL Helper and maybe TSP **********************************/
#include <tcl.h>
#define USE_TK_STUBS 1
#include <tk.h>
#undef DLLEXPORT 
#undef DLLIMPORT 
/***************** DLL EXPORT MAKRO FOR TCC AND GCC ************/
#if (defined(_WIN32) && (defined(_MSC_VER)|| defined(__TINYC__)  || (defined(__BORLANDC__) && (__BORLANDC__ >= 0x0550)) || defined(__LCC__) || defined(__WATCOMC__) || (defined(__GNUC__) && defined(__declspec))))
#undef DLLIMPORT
#undef DLLEXPORT
#   define DLLIMPORT __declspec(dllimport)
#   define DLLEXPORT __declspec(dllexport)
#else
#   define DLLIMPORT 
#   if defined(__GNUC__) && __GNUC__ > 3
#       define DLLEXPORT __attribute__ ((visibility("default")))
#   else
#       define DLLEXPORT
#   endif
#endif
/***************************************************************/
/* START OF PACKAGE_HEADER */
/* don't forget to declare includedir tsp-package/native/clang/ in the right way */
#include <string.h>
#include <tclInt.h>
#include "TSP_cmd.c"
#include "TSP_func.c"
#include "TSP_util.c"
/* END OF PACKAGE_HEADER */
    // init code and include extension
    #include <stdio.h>
    #include <math.h>
    #ifdef __TINYC__
        #define STBI_NO_SIMD
    #endif
    #include "tclstbimage.c"
static int c_stbimage_doinit(Tcl_Interp* interp) {
    Stbimage_Init2(interp);
    return TCL_OK;
}
int tcl_stbimage_doinit(ClientData clientdata, Tcl_Interp *ip, int objc, Tcl_Obj *CONST objv[]) {
  int rv;
  if (objc != 1) {
    Tcl_WrongNumArgs(ip, 1, objv, "");
    return TCL_ERROR;
  }
  rv = c_stbimage_doinit(ip);
  Tcl_SetIntObj(Tcl_GetObjResult(ip), rv);
  return TCL_OK;
}
#ifndef DLLEXPORT 
#define DLLEXPORT __declspec(dllexport)
#endif
DLLEXPORT 
int Stbimage_Init(Tcl_Interp *interp) {
#ifdef USE_TCL_STUBS
  if (Tcl_InitStubs(interp, TCL_VERSION, 0) == 0L) {
    return TCL_ERROR;
  }
#endif
#ifdef USE_TK_STUBS
  if (Tk_InitStubs(interp, TCL_VERSION, 0) == 0L) {
    return TCL_ERROR;
  }
#endif
  Tcl_CreateObjCommand(interp, "stbimage_doinit", tcl_stbimage_doinit, NULL, NULL);
  Tcl_PkgProvide(interp, "stbimage", "1.0");
  return(TCL_OK);
}

