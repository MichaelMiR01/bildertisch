/*
 * CRIMP :: Image Definitions (Implementation).
 * (C) 2010-2011.
 */

/*
 * Import declarations.
 */

#include "coreInt.h"

/*
 * Internal declarations.
 */

static void FreeImage     (Tcl_Obj* imgObjPtr);
static void DupImage      (Tcl_Obj* imgObjPtr,
			   Tcl_Obj* dupObjPtr);
static void StringOfImage (Tcl_Obj* imgObjPtr);
static int  ImageFromAny  (Tcl_Interp* interp,
			   Tcl_Obj* imgObjPtr);

static Tcl_ObjType ImageType = {
    "crimp::image",
    FreeImage,
    DupImage,
    StringOfImage,
    ImageFromAny
};

/*
 * Definitions :: Core.
 */

crimp_image*
crimp_new ( int w, int h)
{
    /*
     * Note: Pixel storage and header describing it are allocated together.
     */

    size_t       size  = sizeof (crimp_image) + CRIMP_RECT_AREA (w, h) * 3;
    crimp_image* image = (crimp_image*) ckalloc (size);

    image->blen = 3;
    image->w     = w;
    image->h     = h;
    image->meta  = NULL;

    return image;
}
crimp_image*
crimp_new4 ( int w, int h)
{
    /*
     * Note: Pixel storage and header describing it are allocated together.
     */

    size_t       size  = sizeof (crimp_image) + CRIMP_RECT_AREA (w, h) * 4;
    crimp_image* image = (crimp_image*) ckalloc (size);

    image->blen = 4;
    image->w     = w;
    image->h     = h;
    image->meta  = NULL;

    return image;
}

crimp_image*
crimp_newm (int blen, int w, int h, Tcl_Obj* meta)
{
    /*
     * Note: Pixel storage and header describing it are allocated together.
     */

    size_t       size  = sizeof (crimp_image) + CRIMP_RECT_AREA (w, h) * blen;
    crimp_image* image = (crimp_image*) ckalloc (size);

    image->blen = blen;
    image->w     = w;
    image->h     = h;
    image->meta  = meta;

    if (meta) {
	Tcl_IncrRefCount (meta);
    }

    return image;
}

crimp_image*
crimp_dup (crimp_image* image)
{
    size_t       size      = sizeof (crimp_image) + crimp_image_area (image) * image->blen;
    crimp_image* new_image = (crimp_image*) ckalloc (size);

    /*
     * Remember the note in function 'crimp_new' above.
     * Pixel storage and header are a single block.
     */

    memcpy (new_image, image, size);
    if (image->meta) {
	Tcl_IncrRefCount (image->meta);
    }

    return new_image;
}

void
crimp_del (crimp_image* image)
{
    /*
     * Remember the note in function 'crimp_new' above.
     * Pixel storage and header are a single block.
     */

    if (image->meta) {
	Tcl_DecrRefCount (image->meta);
    }
    ckfree ((char*) image);
}

/*
 * Definitions :: Tcl.
 */

Tcl_Obj*
crimp_new_image_obj (crimp_image* image)
{
    Tcl_Obj* obj = Tcl_NewObj ();

    Tcl_InvalidateStringRep (obj);
    obj->internalRep.otherValuePtr = image;
    obj->typePtr                   = &ImageType;

    return obj;
}

int
crimp_get_image_from_obj (Tcl_Interp* interp, Tcl_Obj* imageObj, crimp_image** image)
{
    if (imageObj->typePtr != &ImageType) {
	if (ImageFromAny (interp, imageObj) != TCL_OK) {
	    return TCL_ERROR;
	}
    }

    *image = (crimp_image*) imageObj->internalRep.otherValuePtr;
    return TCL_OK;
}

/*
 * Definitions :: ObjType Internals.
 */

static void
FreeImage (Tcl_Obj* imgObjPtr)
{
    crimp_del ((crimp_image*) imgObjPtr->internalRep.otherValuePtr);
}

static void
DupImage (Tcl_Obj* imgObjPtr, Tcl_Obj* dupObjPtr)
{
    crimp_image* ci  = (crimp_image*) imgObjPtr->internalRep.otherValuePtr;

    dupObjPtr->internalRep.otherValuePtr = crimp_dup (ci);
    dupObjPtr->typePtr                   = &ImageType;
}

static void
StringOfImage (Tcl_Obj* imgObjPtr)
{
    crimp_image* ci  = (crimp_image*) imgObjPtr->internalRep.otherValuePtr;
    int length;
    Tcl_DString ds;

    Tcl_DStringInit (&ds);

    /* image type blen */
	char lstring [20];
	sprintf (lstring, "%u", ci->blen);
    Tcl_DStringAppendElement (&ds, lstring);

    /* image width */
    {
	char wstring [20];
	sprintf (wstring, "%u", ci->w);
	Tcl_DStringAppendElement (&ds, wstring);
    }

    /* image height */
    {
	char hstring [20];
	sprintf (hstring, "%u", ci->h);
	Tcl_DStringAppendElement (&ds, hstring);
    }

    /* image client data */
    if (ci->meta) {
	Tcl_DStringAppendElement (&ds, Tcl_GetString (ci->meta));
    } else {
	Tcl_DStringAppendElement (&ds, "");
    }

    /* image pixels */
    {
	/*
	 * Basic length of the various pieces going into the string, from type
	 * name, formatted width/height numbers, number of pixels.
	 */

	char* tmp;
	char* dst;
	size_t sz   = ci->blen * crimp_image_area (ci);
	int plen = sz; /* Tcl length for Tcl_Obj* bytes, 4g limit */
	int expanded, i;

	/*
	 * Now correct the length for the pixels. This is binary data, and the
	 * utf8 representation for 0 and anything >128 needs an additional
	 * byte each. Snarfed from UpdateStringOfByteArray in
	 * generic/tclBinary.c
	 */

	expanded = 0;
	for (i = 0; (i < sz) && (plen >= 0); i++) {
	    if ((ci->pixel[i] == 0) || (ci->pixel[i] > 127)) {
		plen ++;
		expanded = 1;
	    }
	}

	if (plen < 0) {
	    Tcl_Panic("max size for a Tcl value (%d bytes) exceeded", INT_MAX);
	}

	/*
	 * We need the temporary array because ...AppendElement below expects
	 * a 0-terminated string, and the pixels aren't
	 */

	dst = tmp = CRIMP_ALLOC_ARRAY (plen+1, char);
	if (expanded) {
	    /*
	     * If bytes have to be expanded we have to handle them 1-by-1.
	     */
	    for (i = 0; i < sz; i++) {
		dst += Tcl_UniCharToUtf(ci->pixel[i], dst);
	    }
	} else {
	    /*
	     * All bytes are represented by single chars. We can copy them as a
	     * block.
	     */
	    memcpy(dst, ci->pixel, (size_t) plen);
	    dst += plen;
	}
	*dst = '\0';

	/*
	 * Note that this adds another layer of quoting to the string:
	 * list quoting.
	 */
	Tcl_DStringAppendElement (&ds, tmp);
	ckfree (tmp);
    }

    length = Tcl_DStringLength (&ds);

    imgObjPtr->bytes  = CRIMP_ALLOC_ARRAY (length+1, char);
    imgObjPtr->length = length;

    memcpy (imgObjPtr->bytes, Tcl_DStringValue (&ds), length+1);

    Tcl_DStringFree (&ds);
}

static int
ImageFromAny (Tcl_Interp* interp, Tcl_Obj* imgObjPtr)
{
    int       objc;
    Tcl_Obj **objv;
    int w, h, bl, length;
    crimp_pixel_array pixel;
    crimp_image* ci;
    Tcl_Obj* meta;

    if (Tcl_ListObjGetElements(interp, imgObjPtr, &objc, &objv) != TCL_OK) {
	return TCL_ERROR;
    }

    if (objc != 5) {
    invalid:
	Tcl_SetResult(interp, "invalid image format", TCL_STATIC);
	return TCL_ERROR;
    }

    if ((Tcl_GetIntFromObj            (interp, objv[1], &w) != TCL_OK) ||
	(Tcl_GetIntFromObj            (interp, objv[2], &h) != TCL_OK) ||
	(Tcl_GetIntFromObj            (interp, objv[0], &bl) != TCL_OK) ||
	(w < 0) || (h < 0)) {
	Tcl_SetResult(interp, "invalid image format", TCL_STATIC);
	return TCL_ERROR;
    }

    pixel = Tcl_GetByteArrayFromObj (objv[4], &length);
    if (length != (bl * CRIMP_RECT_AREA (w, h))) {
	Tcl_SetResult(interp, "invalid image format", TCL_STATIC);
	return TCL_ERROR;
    }

    meta = objv[3];

    ci = crimp_newm (bl, w, h, meta);
    memcpy(ci->pixel, pixel, length);

    /*
     * Kill the old intrep. This was delayed as much as possible.
     */

    FreeIntRep (imgObjPtr);

    /*
     * Now we can put in our own intrep.
     */

    imgObjPtr->internalRep.otherValuePtr = ci;
    imgObjPtr->typePtr                   = &ImageType;

    return TCL_OK;
}

/*
 * Local Variables:
 * mode: c
 * c-basic-offset: 4
 * fill-column: 78
 * End:
 */
