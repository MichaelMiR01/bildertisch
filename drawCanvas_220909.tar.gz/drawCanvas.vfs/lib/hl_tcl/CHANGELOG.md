# Last changes:


Version `0.9.37 (21 Mar'22)`

  - BUGFIX: highlighting several adjacent quotes ("" "") in plain texts


Version `0.9.36 (8 Mar'22)`

  - NEW   : quotes highlighted
  - CHANGE: docs


Version `0.9.34 (26 Jan'22)`

  - CHANGE: hl_tcl::addingColors - try to get $dark from apave


Version `0.9.33 (19 Jan'22)`

  - NEW   : #TODO and #! comments highlighted specially
  - NEW   : hl_tcl::addingColors to get two adding colors
  - CHANGE: hl_tcl_html.tcl counts $darkedit


Version `0.9.32 (15 Jan'22)`

  - CHANGE: 'namespace eval' to be highlighted like proc/return
  - CHANGE: 'SYNTAXCOLORS,2' made green