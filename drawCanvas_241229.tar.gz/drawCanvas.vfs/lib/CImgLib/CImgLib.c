/***************** Automatically Created with TCC4TCL Helper and maybe TSP **********************************/
/* Compiler directives are raw estimates, please adapt to given pathstructure */

/* for gccwin32 use */
/* /host/data/tcl/tcc_0.9.27-bin/gcc/bin/gcc.exe  -s -m32 -D_WIN32 -static-libgcc  -shared -DUSE_TCL_STUBS -O2  -Iinclude -Iinclude/generic -Iinclude/generic/win -Iinclude/xlib -Itsp-package/native/clang/ -I./done/CImgLib -I./done/CImgLib -I./done/CImgLib/jpeg ./done/CImgLib/CImgLib.c -o./done/CImgLib/CImgLib.dll -Llib -ltclstub86 -ltkstub86 -Llib -ljpeg62 -L./done/CImgLib -L./done/CImgLib */

/* for tccwin32 use */
/* /host/data/tcl/tcc_0.9.27-bin/tcc.exe  -m32 -D_WIN32  -shared -DUSE_TCL_STUBS -O2  -Iinclude -Iinclude/stdinc -Iinclude/generic -Iinclude/generic/win -Iinclude/xlib -Iwin32 -Iwin32/winapi  -Itsp-package/native/clang/ -I./done/CImgLib -I./done/CImgLib -I./done/CImgLib/jpeg ./done/CImgLib/CImgLib.c -o./done/CImgLib/CImgLib.dll -ltclstub86elf -ltkstub86elf -Llib -ljpeg62 -L./done/CImgLib -L./done/CImgLib */

/* for gcc use */
/* /host/data/tcl/tcc_0.9.27-bin/gcc/bin/gcc.exe  -s -m32 -D_WIN32 -static-libgcc  -shared -DUSE_TCL_STUBS -O2  -Iinclude -Iinclude/generic -Iinclude/generic/win -Iinclude/xlib -Itsp-package/native/clang/ -I./done/CImgLib -I./done/CImgLib -I./done/CImgLib/jpeg ./done/CImgLib/CImgLib.c -o./done/CImgLib/CImgLib.dll -Llib -ltclstub86 -ltkstub86 -Llib -ljpeg62 -L./done/CImgLib -L./done/CImgLib */

/* for tcc use */
/* /host/data/tcl/tcc_0.9.27-bin/tcc.exe  -m32 -D_WIN32  -shared -DUSE_TCL_STUBS -O2  -Iinclude -Iinclude/stdinc -Iinclude/generic -Iinclude/generic/win -Iinclude/xlib -Iwin32 -Iwin32/winapi  -Itsp-package/native/clang/ -I./done/CImgLib -I./done/CImgLib -I./done/CImgLib/jpeg ./done/CImgLib/CImgLib.c -o./done/CImgLib/CImgLib.dll -ltclstub86elf -ltkstub86elf -Llib -ljpeg62 -L./done/CImgLib -L./done/CImgLib */

/***************** Automatically Created with TCC4TCL Helper and maybe TSP **********************************/
#include <tcl.h>
#define USE_TK_STUBS 1
#include <tk.h>
#undef DLLEXPORT 
#undef DLLIMPORT 
/***************** DLL EXPORT MAKRO FOR TCC AND GCC ************/
#if (defined(_WIN32) && (defined(_MSC_VER)|| defined(__TINYC__)  || (defined(__BORLANDC__) && (__BORLANDC__ >= 0x0550)) || defined(__LCC__) || defined(__WATCOMC__) || (defined(__GNUC__) && defined(__declspec))))
#undef DLLIMPORT
#undef DLLEXPORT
#   define DLLIMPORT __declspec(dllimport)
#   define DLLEXPORT __declspec(dllexport)
#else
#   define DLLIMPORT 
#   if defined(__GNUC__) && __GNUC__ > 3
#       define DLLEXPORT __attribute__ ((visibility("default")))
#   else
#       define DLLEXPORT
#   endif
#endif
/***************************************************************/
/* START OF PACKAGE_HEADER */
/* don't forget to declare includedir tsp-package/native/clang/ in the right way */
#include <string.h>
#include <tclInt.h>
#include "TSP_cmd.c"
#include "TSP_func.c"
#include "TSP_util.c"
/* END OF PACKAGE_HEADER */
    #include <stdio.h>
    #include <math.h>
    #include "tccimage.h"
    #include "tcchaldlut.h"
    #include "tccimage.c"
    #include "tccimage_manip.c"
    #include "tccreadjpg.c"
static int c_CImg_testlut(int r0, int g0, int b0) {
    long int rx,ry,size,dim;
    size=1728;
    dim=size2dim(size);
    rx=lutX(r0,g0,b0,dim);
    ry=lutY(r0,g0,b0,dim);
    return rx*10000+ry;
}
int tcl_CImg_testlut(ClientData clientdata, Tcl_Interp *ip, int objc, Tcl_Obj *CONST objv[]) {
  int _r0;
  int _g0;
  int _b0;
  int rv;
  if (objc != 4) {
    Tcl_WrongNumArgs(ip, 1, objv, "r0 g0 b0");
    return TCL_ERROR;
  }
  if (Tcl_GetIntFromObj(ip, objv[1], &_r0) != TCL_OK)    return TCL_ERROR;
  if (Tcl_GetIntFromObj(ip, objv[2], &_g0) != TCL_OK)    return TCL_ERROR;
  if (Tcl_GetIntFromObj(ip, objv[3], &_b0) != TCL_OK)    return TCL_ERROR;
  rv = c_CImg_testlut(_r0, _g0, _b0);
  Tcl_SetIntObj(Tcl_GetObjResult(ip), rv);
  return TCL_OK;
}
Tcl_Obj* CImg_import(Tcl_Interp* interp, char* im1);
int tcl_CImg_import(ClientData clientdata, Tcl_Interp *ip, int objc, Tcl_Obj *CONST objv[]) {
  char* _im1;
  Tcl_Obj* rv;
  if (objc != 2) {
    Tcl_WrongNumArgs(ip, 1, objv, "im1");
    return TCL_ERROR;
  }
  _im1 = Tcl_GetString(objv[1]);
  rv = CImg_import(ip, _im1);
  if (rv == NULL) {
    return(TCL_ERROR);
  }
  Tcl_SetObjResult(ip, rv); /*Tcl_DecrRefCount(rv);*/
  return TCL_OK;
}
int CImg_export(Tcl_Interp* interp, Tcl_Obj* imageObj, char* im1);
int tcl_CImg_export(ClientData clientdata, Tcl_Interp *ip, int objc, Tcl_Obj *CONST objv[]) {
  Tcl_Obj* _imageObj;
  char* _im1;
  int rv;
  if (objc != 3) {
    Tcl_WrongNumArgs(ip, 1, objv, "imageObj im1");
    return TCL_ERROR;
  }
  _imageObj = objv[1];
  _im1 = Tcl_GetString(objv[2]);
  rv = CImg_export(ip, _imageObj, _im1);
  return rv;
}
int CImg_width(Tcl_Obj* imageObj);
int tcl_CImg_width(ClientData clientdata, Tcl_Interp *ip, int objc, Tcl_Obj *CONST objv[]) {
  Tcl_Obj* _imageObj;
  int rv;
  if (objc != 2) {
    Tcl_WrongNumArgs(ip, 1, objv, "imageObj");
    return TCL_ERROR;
  }
  _imageObj = objv[1];
  rv = CImg_width(_imageObj);
  Tcl_SetIntObj(Tcl_GetObjResult(ip), rv);
  return TCL_OK;
}
int CImg_height(Tcl_Obj* imageObj);
int tcl_CImg_height(ClientData clientdata, Tcl_Interp *ip, int objc, Tcl_Obj *CONST objv[]) {
  Tcl_Obj* _imageObj;
  int rv;
  if (objc != 2) {
    Tcl_WrongNumArgs(ip, 1, objv, "imageObj");
    return TCL_ERROR;
  }
  _imageObj = objv[1];
  rv = CImg_height(_imageObj);
  Tcl_SetIntObj(Tcl_GetObjResult(ip), rv);
  return TCL_OK;
}
Tcl_Obj* CImg_pixel(Tcl_Obj* imageObj);
int tcl_CImg_pixel(ClientData clientdata, Tcl_Interp *ip, int objc, Tcl_Obj *CONST objv[]) {
  Tcl_Obj* _imageObj;
  Tcl_Obj* rv;
  if (objc != 2) {
    Tcl_WrongNumArgs(ip, 1, objv, "imageObj");
    return TCL_ERROR;
  }
  _imageObj = objv[1];
  rv = CImg_pixel(_imageObj);
  if (rv == NULL) {
    return(TCL_ERROR);
  }
  Tcl_SetObjResult(ip, rv); /*Tcl_DecrRefCount(rv);*/
  return TCL_OK;
}
int CImg_iterate_kernel_int(Tcl_Interp* interp, Tcl_Obj* imageObj, Tcl_Obj* kernelobj, int kernelsize, double coeff, double linG);
int tcl_CImg_iterate_kernel_int(ClientData clientdata, Tcl_Interp *ip, int objc, Tcl_Obj *CONST objv[]) {
  Tcl_Obj* _imageObj;
  Tcl_Obj* _kernelobj;
  int _kernelsize;
  double _coeff;
  double _linG;
  int rv;
  if (objc != 6) {
    Tcl_WrongNumArgs(ip, 1, objv, "imageObj kernelobj kernelsize coeff linG");
    return TCL_ERROR;
  }
  _imageObj = objv[1];
  _kernelobj = objv[2];
  if (Tcl_GetIntFromObj(ip, objv[3], &_kernelsize) != TCL_OK)    return TCL_ERROR;
  if (Tcl_GetDoubleFromObj(ip, objv[4], &_coeff) != TCL_OK)    return TCL_ERROR;
  if (Tcl_GetDoubleFromObj(ip, objv[5], &_linG) != TCL_OK)    return TCL_ERROR;
  rv = CImg_iterate_kernel_int(ip, _imageObj, _kernelobj, _kernelsize, _coeff, _linG);
  return rv;
}
int CImg_iterate_channel(Tcl_Interp* interp, Tcl_Obj* imageObj, Tcl_Obj* lutObj, int chanoffset, double coeff, double linG);
int tcl_CImg_iterate_channel(ClientData clientdata, Tcl_Interp *ip, int objc, Tcl_Obj *CONST objv[]) {
  Tcl_Obj* _imageObj;
  Tcl_Obj* _lutObj;
  int _chanoffset;
  double _coeff;
  double _linG;
  int rv;
  if (objc != 6) {
    Tcl_WrongNumArgs(ip, 1, objv, "imageObj lutObj chanoffset coeff linG");
    return TCL_ERROR;
  }
  _imageObj = objv[1];
  _lutObj = objv[2];
  if (Tcl_GetIntFromObj(ip, objv[3], &_chanoffset) != TCL_OK)    return TCL_ERROR;
  if (Tcl_GetDoubleFromObj(ip, objv[4], &_coeff) != TCL_OK)    return TCL_ERROR;
  if (Tcl_GetDoubleFromObj(ip, objv[5], &_linG) != TCL_OK)    return TCL_ERROR;
  rv = CImg_iterate_channel(ip, _imageObj, _lutObj, _chanoffset, _coeff, _linG);
  return rv;
}
int CImg_mirror(Tcl_Interp* interp, Tcl_Obj* imageObj, int flipx, int flipy);
int tcl_CImg_mirror(ClientData clientdata, Tcl_Interp *ip, int objc, Tcl_Obj *CONST objv[]) {
  Tcl_Obj* _imageObj;
  int _flipx;
  int _flipy;
  int rv;
  if (objc != 4) {
    Tcl_WrongNumArgs(ip, 1, objv, "imageObj flipx flipy");
    return TCL_ERROR;
  }
  _imageObj = objv[1];
  if (Tcl_GetIntFromObj(ip, objv[2], &_flipx) != TCL_OK)    return TCL_ERROR;
  if (Tcl_GetIntFromObj(ip, objv[3], &_flipy) != TCL_OK)    return TCL_ERROR;
  rv = CImg_mirror(ip, _imageObj, _flipx, _flipy);
  return rv;
}
static int c_CImg_fastreadjpg(Tcl_Interp* interp, char* imname, char* img, int maxsize) {
    Tk_PhotoHandle handle;
    handle = Tk_FindPhoto(interp,img);
    if (handle == NULL) return TCL_ERROR;
    //read_JPEG_file(imname);
    int orientation=tcc_jpgread_resize(interp,imname, handle,      0,0,maxsize,maxsize,0,0);
    return orientation;
}
int tcl_CImg_fastreadjpg(ClientData clientdata, Tcl_Interp *ip, int objc, Tcl_Obj *CONST objv[]) {
  char* _imname;
  char* _img;
  int _maxsize;
  int rv;
  if (objc != 4) {
    Tcl_WrongNumArgs(ip, 1, objv, "imname img maxsize");
    return TCL_ERROR;
  }
  _imname = Tcl_GetString(objv[1]);
  _img = Tcl_GetString(objv[2]);
  if (Tcl_GetIntFromObj(ip, objv[3], &_maxsize) != TCL_OK)    return TCL_ERROR;
  rv = c_CImg_fastreadjpg(ip, _imname, _img, _maxsize);
  Tcl_SetIntObj(Tcl_GetObjResult(ip), rv);
  return TCL_OK;
}
int CImg_imageResize(Tcl_Interp* interp, char* src, char* dest, int newrows, int newcols);
int tcl_CImg_imageResize(ClientData clientdata, Tcl_Interp *ip, int objc, Tcl_Obj *CONST objv[]) {
  char* _src;
  char* _dest;
  int _newrows;
  int _newcols;
  int rv;
  if (objc != 5) {
    Tcl_WrongNumArgs(ip, 1, objv, "src dest newrows newcols");
    return TCL_ERROR;
  }
  _src = Tcl_GetString(objv[1]);
  _dest = Tcl_GetString(objv[2]);
  if (Tcl_GetIntFromObj(ip, objv[3], &_newrows) != TCL_OK)    return TCL_ERROR;
  if (Tcl_GetIntFromObj(ip, objv[4], &_newcols) != TCL_OK)    return TCL_ERROR;
  rv = CImg_imageResize(ip, _src, _dest, _newrows, _newcols);
  return rv;
}
int CImg_rotate(Tcl_Interp* interp, Tcl_Obj* imageObj, int direction);
int tcl_CImg_rotate(ClientData clientdata, Tcl_Interp *ip, int objc, Tcl_Obj *CONST objv[]) {
  Tcl_Obj* _imageObj;
  int _direction;
  int rv;
  if (objc != 3) {
    Tcl_WrongNumArgs(ip, 1, objv, "imageObj direction");
    return TCL_ERROR;
  }
  _imageObj = objv[1];
  if (Tcl_GetIntFromObj(ip, objv[2], &_direction) != TCL_OK)    return TCL_ERROR;
  rv = CImg_rotate(ip, _imageObj, _direction);
  return rv;
}
int CImg_fastscale(Tcl_Interp* interp, char* srcName, char* destName, int newwid, int newhgt, int scaler);
int tcl_CImg_fastscale(ClientData clientdata, Tcl_Interp *ip, int objc, Tcl_Obj *CONST objv[]) {
  char* _srcName;
  char* _destName;
  int _newwid;
  int _newhgt;
  int _scaler;
  int rv;
  if (objc != 6) {
    Tcl_WrongNumArgs(ip, 1, objv, "srcName destName newwid newhgt scaler");
    return TCL_ERROR;
  }
  _srcName = Tcl_GetString(objv[1]);
  _destName = Tcl_GetString(objv[2]);
  if (Tcl_GetIntFromObj(ip, objv[3], &_newwid) != TCL_OK)    return TCL_ERROR;
  if (Tcl_GetIntFromObj(ip, objv[4], &_newhgt) != TCL_OK)    return TCL_ERROR;
  if (Tcl_GetIntFromObj(ip, objv[5], &_scaler) != TCL_OK)    return TCL_ERROR;
  rv = CImg_fastscale(ip, _srcName, _destName, _newwid, _newhgt, _scaler);
  return rv;
}
static int c_CImg_loaded(void) {
    return TCL_OK;
}
int tcl_CImg_loaded(ClientData clientdata, Tcl_Interp *ip, int objc, Tcl_Obj *CONST objv[]) {
  int rv;
  if (objc != 1) {
    Tcl_WrongNumArgs(ip, 1, objv, "");
    return TCL_ERROR;
  }
  rv = c_CImg_loaded();
  Tcl_SetIntObj(Tcl_GetObjResult(ip), rv);
  return TCL_OK;
}
Tcl_Obj* makeLUT_cc(double gamma, double mmin, double mmax, double offset, double factor);
int tcl_makeLUT_cc(ClientData clientdata, Tcl_Interp *ip, int objc, Tcl_Obj *CONST objv[]) {
  double _gamma;
  double _mmin;
  double _mmax;
  double _offset;
  double _factor;
  Tcl_Obj* rv;
  if (objc != 6) {
    Tcl_WrongNumArgs(ip, 1, objv, "gamma mmin mmax offset factor");
    return TCL_ERROR;
  }
  if (Tcl_GetDoubleFromObj(ip, objv[1], &_gamma) != TCL_OK)    return TCL_ERROR;
  if (Tcl_GetDoubleFromObj(ip, objv[2], &_mmin) != TCL_OK)    return TCL_ERROR;
  if (Tcl_GetDoubleFromObj(ip, objv[3], &_mmax) != TCL_OK)    return TCL_ERROR;
  if (Tcl_GetDoubleFromObj(ip, objv[4], &_offset) != TCL_OK)    return TCL_ERROR;
  if (Tcl_GetDoubleFromObj(ip, objv[5], &_factor) != TCL_OK)    return TCL_ERROR;
  rv = makeLUT_cc(_gamma, _mmin, _mmax, _offset, _factor);
  if (rv == NULL) {
    return(TCL_ERROR);
  }
  Tcl_SetObjResult(ip, rv); /*Tcl_DecrRefCount(rv);*/
  return TCL_OK;
}
#undef CLEANUP
#undef RETURN_VALUE_CLEANUP
#undef RETURN_VALUE
#undef ERROR_EXIT
#define ERROR_EXIT goto error_exit
#define CLEANUP  \
\
    \
    if (_tmpVar_cmdResultObj != NULL) { Tcl_DecrRefCount(_tmpVar_cmdResultObj); _tmpVar_cmdResultObj = NULL; } \
    \
    if (_tmpVar_var_1 != NULL) { Tcl_DecrRefCount(_tmpVar_var_1); _tmpVar_var_1 = NULL; } \
    if (__clut != NULL) { Tcl_DecrRefCount(__clut); __clut = NULL; } \
    if (__lut != NULL) { Tcl_DecrRefCount(__lut); __lut = NULL; } \
    \

#define RETURN_VALUE_CLEANUP
#define RETURN_VALUE returnValue
/* 
 * compiled proc implementation 
 *
 */
Tcl_Obj*
TSP_UserDirect_makeLUT_c(Tcl_Interp* interp, int* rc  , double __gamma, double __min, double __max, double __offset, double __factor ) {
    static int directInit = 0;
    int i;          /* for loop */
    int len;        /* len, idx1, idx2, str, str2 -for use by lang_string, et.al. */
    int idx1;
    int idx2;
    char* str1;     
    char* str2;     
    char* exprErrMsg ;
    Tcl_Obj* _tmpVar_cmdResultObj = NULL;
    Tcl_CallFrame* frame; 
    Tcl_Obj* returnValue = NULL;
    Tcl_Obj** foreachObjv_0 = NULL;
    Tcl_Obj*  argObjvArray_1[4];
    int       argObjc_1 = 0;
    Tcl_Obj** foreachObjv_1 = NULL;
    /* stack allocated strings */
    /* variables defined in proc, plus temp vars */
    int _tmpVar_boolean_1;
    double _tmpVar_double_1;
    Tcl_Obj* _tmpVar_var_1 = NULL;
    Tcl_Obj* __clut = NULL;
    Tcl_WideInt __i;
    Tcl_Obj* __lut = NULL;
    Tcl_WideInt __v;
    /* constants used for direct tcl and tcl invoked commands */
    /* const: format */
    static Tcl_Obj* _constant_1 = NULL;
    /* const: c* */
    static Tcl_Obj* _constant_2 = NULL;
    /* initialize return value */
    /* initialize string vars */
    /* var arguments need to be preserved, since they are released in CLEANUP */
    /* string arguments need to be copied (FIXME: investigate using COW for strings) */
    /* initialize function pointers for calling other compiled procs, constants */
    if (! directInit) {
        directInit = 1;
        _constant_1 = TSP_Util_const_string("format");/*from create_compilable*/
        _constant_2 = TSP_Util_const_string("c*");/*from create_compilable*/
    }
    /* Native proc, no external variables used, dropping PushCallframe/PopCallframe */
    *rc = TCL_OK;     
    /* code must return a value as defined by procdef (unless void), else will raise a compile error */
    /* does only gcc do this with the right option?  what about tcc/clang/msvc++? */
    /******** makeLUT_c 6: set lut "" */
    /***** ::tsp::gen_assign_scalar_text */
    /* ::tsp::lang_assign_var_string */
    __lut = TSP_Util_lang_assign_var_string_const(__lut, "");
    /******** makeLUT_c 7: for {set i 0} {$i<256} {incr i} {.        set v... */
    /***** ::tsp::gen_command_for */
    /* ::tsp::gen_command_for initializer*/
    /******** makeLUT_c 7: set i 0 */
    /***** ::tsp::gen_assign_scalar_text */
    __i = 0LL;
    /* ::tsp::lang_while */
    /* evaluate condition */
    _tmpVar_boolean_1 = (__i < 256);
    while ( _tmpVar_boolean_1 ) {
        /******** makeLUT_c 8: set v [expr {max(0,min(255,round( $offset+$min+(... */
        /***** ::tsp::generate_set assign from command (set v = _tmpVar_double_1) */
        /******** makeLUT_c 8: expr {max(0,min(255,round( $offset+$min+($max-$m... */
        exprErrMsg = NULL;
        _tmpVar_double_1 = TSP_func_max(0, TSP_func_min(255, TSP_func_round(((__offset + __min) + (((__max - __min) * __factor) * TSP_func_double_pow(TSP_func_double_div((1.0 * __i), 255.0), TSP_func_double_div(1.0, __gamma)))))));
        if (exprErrMsg != NULL) {
            Tcl_ResetResult(interp);
            Tcl_AppendResult(interp, exprErrMsg, ", in proc: makeLUT_c line: 8", (char*)NULL);
            *rc = TCL_ERROR;
            ERROR_EXIT;
        }
        /***** ::tsp::gen_assign_scalar_scalar */
        __v = (Tcl_WideInt) _tmpVar_double_1;
        /******** makeLUT_c 9: lappend lut $v */
        /***** ::tsp::gen_command_lappend */
        /* ::tsp::lang_dup_var_if_shared */
        if (__lut != NULL) {
            if (Tcl_IsShared(__lut)) {
                Tcl_DecrRefCount(__lut);
                __lut = Tcl_DuplicateObj(__lut);
                Tcl_IncrRefCount(__lut);
            }
        } else {
            __lut = Tcl_NewStringObj("",-1);
            Tcl_IncrRefCount(__lut);
        }
        /***** ::tsp::gen_assign_scalar_scalar */
        /* ::tsp::lang_assign_var_int */
        _tmpVar_var_1 = TSP_Util_lang_assign_var_int(_tmpVar_var_1, (TCL_WIDE_INT_TYPE) __v);
        /* ::tsp::lang_lappend_var */
        Tcl_ListObjAppendElement(interp, __lut, _tmpVar_var_1);
        /* ::tsp::gen_command_for postloop */
        /******** makeLUT_c 7: incr i */
        __i = __i + (1);
        /* evaluate condition */
        _tmpVar_boolean_1 = (__i < 256);
    }
    /******** makeLUT_c 11: set clut [binary format c* $lut] */
    /***** ::tsp::generate_set assign from command (set clut = _tmpVar_cmdResultObj) */
    /******** makeLUT_c 11: binary format c* $lut */
    /***** ::tsp::gen_direct_tcl binary */
    argObjvArray_1[0] = NULL;
    argObjvArray_1[1] = _constant_1;
    argObjvArray_1[2] = _constant_2;
    argObjvArray_1[3] = __lut;
    /*  ::tsp::lang_invoke_builtin */
    if ((*rc = (TSP_Cmd_builtin_binary) ((ClientData)NULL, interp,  4, argObjvArray_1)) != TCL_OK) {
        ERROR_EXIT;
    }
    if (_tmpVar_cmdResultObj != NULL) { Tcl_DecrRefCount(_tmpVar_cmdResultObj); _tmpVar_cmdResultObj = NULL; } 
    _tmpVar_cmdResultObj = Tcl_GetObjResult(interp);
    Tcl_IncrRefCount(_tmpVar_cmdResultObj);
    /***** ::tsp::gen_assign_scalar_scalar */
    /* ::tsp::lang_assign_var_var */
    __clut = TSP_Util_lang_assign_var_var(__clut, _tmpVar_cmdResultObj);
    /******** makeLUT_c 12: return $clut */
    /***** ::tsp::gen_command_return */
    /***** ::tsp::gen_assign_scalar_scalar */
    /* ::tsp::lang_assign_var_var */
    _tmpVar_var_1 = TSP_Util_lang_assign_var_var(_tmpVar_var_1, __clut);
    Tcl_IncrRefCount(_tmpVar_var_1);
    /* ::tsp::lang_return */
    returnValue = _tmpVar_var_1;
    Tcl_IncrRefCount(returnValue);
    *rc = TCL_OK;
    CLEANUP;
    /* returnValue is cleaned up by calling proc */;
    return RETURN_VALUE;
    /* if void, then we can jump to normal_exit, if not-void, then that means the proc fell through */
    /* without returning a value.  in that case, set result and return error code*/
    Tcl_SetResult(interp, "end of proc encountered without 'return' command, proc type: var", TCL_STATIC); goto error_exit;    
  error_exit:
    *rc = TCL_ERROR;
  normal_exit:
    CLEANUP;
    RETURN_VALUE_CLEANUP;
    return RETURN_VALUE;
}
/* redefine macros for the Tcl interface function */
#undef CLEANUP
#undef RETURN_VALUE_CLEANUP
#undef RETURN_VALUE
#undef ERROR_EXIT
#define CLEANUP \

#define RETURN_VALUE_CLEANUP 
#define RETURN_VALUE 
#define ERROR_EXIT goto error_exit
/* 
 * Tcl command interface 
 *
 */
int makeLUT_c(ClientData clientData, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]) {
    int _rc;
    int* rc = &_rc;;
    Tcl_Obj* returnValue = NULL;
    /* variables used by this command, assigned from objv array */
    double __gamma;
    double __min;
    double __max;
    double __offset;
    double __factor;
    /* allow other compiled procs to find the this proc function at runtime, see TSP_cmd.TSP_User_getCmd() */
    if (clientData != NULL && objc == 0) {
        void** cd = clientData;
        *cd = (void*) TSP_UserDirect_makeLUT_c;
        return TCL_OK;
    }
    /* check arg count */
    if (objc != 6) {
        Tcl_WrongNumArgs(interp, 1, objv, "gamma min max offset factor");
        return TCL_ERROR;
    }
    /* assign arg variable from objv array */
    /* ::tsp::lang_convert_double_var */
    if ((*rc = Tcl_GetDoubleFromObj(interp, objv[1], &__gamma)) != TCL_OK) {
        Tcl_AppendResult(interp, "can't convert arg 1 to double", "objv[1]", (char *) NULL);
        ERROR_EXIT;
    }
    /* ::tsp::lang_convert_double_var */
    if ((*rc = Tcl_GetDoubleFromObj(interp, objv[2], &__min)) != TCL_OK) {
        Tcl_AppendResult(interp, "can't convert arg 2 to double", "objv[2]", (char *) NULL);
        ERROR_EXIT;
    }
    /* ::tsp::lang_convert_double_var */
    if ((*rc = Tcl_GetDoubleFromObj(interp, objv[3], &__max)) != TCL_OK) {
        Tcl_AppendResult(interp, "can't convert arg 3 to double", "objv[3]", (char *) NULL);
        ERROR_EXIT;
    }
    /* ::tsp::lang_convert_double_var */
    if ((*rc = Tcl_GetDoubleFromObj(interp, objv[4], &__offset)) != TCL_OK) {
        Tcl_AppendResult(interp, "can't convert arg 4 to double", "objv[4]", (char *) NULL);
        ERROR_EXIT;
    }
    /* ::tsp::lang_convert_double_var */
    if ((*rc = Tcl_GetDoubleFromObj(interp, objv[5], &__factor)) != TCL_OK) {
        Tcl_AppendResult(interp, "can't convert arg 5 to double", "objv[5]", (char *) NULL);
        ERROR_EXIT;
    }
    /* invoke compiled proc method */
    _rc = TCL_OK;
    returnValue = TSP_UserDirect_makeLUT_c(interp, &_rc , __gamma, __min, __max, __offset, __factor);
    if (_rc == TCL_OK) {
        Tcl_SetObjResult(interp, returnValue);
        /* ok to fall through */
    }
  error_exit:
    CLEANUP;
    return _rc;
}
#undef CLEANUP
#undef RETURN_VALUE_CLEANUP
#undef RETURN_VALUE
#undef ERROR_EXIT
#define ERROR_EXIT goto error_exit
#define CLEANUP  \
\
    \
    if (_tmpVar_cmdResultObj != NULL) { Tcl_DecrRefCount(_tmpVar_cmdResultObj); _tmpVar_cmdResultObj = NULL; } \
    \
    if (_tmpVar_var_1 != NULL) { Tcl_DecrRefCount(_tmpVar_var_1); _tmpVar_var_1 = NULL; } \
    if (__clut != NULL) { Tcl_DecrRefCount(__clut); __clut = NULL; } \
    if (__lut != NULL) { Tcl_DecrRefCount(__lut); __lut = NULL; } \
    \

#define RETURN_VALUE_CLEANUP
#define RETURN_VALUE returnValue
/* 
 * compiled proc implementation 
 *
 */
Tcl_Obj*
TSP_UserDirect_makeSLUT_c(Tcl_Interp* interp, int* rc  , double __gamma, double __min, double __max, double __offset, double __factor ) {
    static int directInit = 0;
    int i;          /* for loop */
    int len;        /* len, idx1, idx2, str, str2 -for use by lang_string, et.al. */
    int idx1;
    int idx2;
    char* str1;     
    char* str2;     
    char* exprErrMsg ;
    Tcl_Obj* _tmpVar_cmdResultObj = NULL;
    Tcl_CallFrame* frame; 
    Tcl_Obj* returnValue = NULL;
    Tcl_Obj** foreachObjv_0 = NULL;
    Tcl_Obj*  argObjvArray_1[4];
    int       argObjc_1 = 0;
    Tcl_Obj** foreachObjv_1 = NULL;
    /* stack allocated strings */
    /* variables defined in proc, plus temp vars */
    int _tmpVar_boolean_1;
    double _tmpVar_double_1;
    Tcl_WideInt _tmpVar_int_1;
    Tcl_Obj* _tmpVar_var_1 = NULL;
    Tcl_Obj* __clut = NULL;
    Tcl_WideInt __i;
    Tcl_Obj* __lut = NULL;
    double __mean;
    double __ps;
    double __s;
    double __span;
    double __sv;
    Tcl_WideInt __v;
    double __vf;
    double __vs;
    /* constants used for direct tcl and tcl invoked commands */
    /* const: format */
    static Tcl_Obj* _constant_1 = NULL;
    /* const: c* */
    static Tcl_Obj* _constant_2 = NULL;
    /* initialize return value */
    /* initialize string vars */
    /* var arguments need to be preserved, since they are released in CLEANUP */
    /* string arguments need to be copied (FIXME: investigate using COW for strings) */
    /* initialize function pointers for calling other compiled procs, constants */
    if (! directInit) {
        directInit = 1;
        _constant_1 = TSP_Util_const_string("format");/*from create_compilable*/
        _constant_2 = TSP_Util_const_string("c*");/*from create_compilable*/
    }
    /* Native proc, no external variables used, dropping PushCallframe/PopCallframe */
    *rc = TCL_OK;     
    /* code must return a value as defined by procdef (unless void), else will raise a compile error */
    /* does only gcc do this with the right option?  what about tcc/clang/msvc++? */
    /******** makeSLUT_c 6: set lut "" */
    /***** ::tsp::gen_assign_scalar_text */
    /* ::tsp::lang_assign_var_string */
    __lut = TSP_Util_lang_assign_var_string_const(__lut, "");
    /******** makeSLUT_c 7: for {set i 0} {$i<256} {incr i} {.        set v... */
    /***** ::tsp::gen_command_for */
    /* ::tsp::gen_command_for initializer*/
    /******** makeSLUT_c 7: set i 0 */
    /***** ::tsp::gen_assign_scalar_text */
    __i = 0LL;
    /* ::tsp::lang_while */
    /* evaluate condition */
    _tmpVar_boolean_1 = (__i < 256);
    while ( _tmpVar_boolean_1 ) {
        /******** makeSLUT_c 8: set v [expr {max(0,min(255,round( $offset+$min+(... */
        /***** ::tsp::generate_set assign from command (set v = _tmpVar_double_1) */
        /******** makeSLUT_c 8: expr {max(0,min(255,round( $offset+$min+($max-$m... */
        exprErrMsg = NULL;
        _tmpVar_double_1 = TSP_func_max(0, TSP_func_min(255, TSP_func_round(((__offset + __min) + (((__max - __min) * __factor) * TSP_func_double_pow(TSP_func_double_div((1.0 * __i), 255.0), TSP_func_double_div(1.0, __gamma)))))));
        if (exprErrMsg != NULL) {
            Tcl_ResetResult(interp);
            Tcl_AppendResult(interp, exprErrMsg, ", in proc: makeSLUT_c line: 8", (char*)NULL);
            *rc = TCL_ERROR;
            ERROR_EXIT;
        }
        /***** ::tsp::gen_assign_scalar_scalar */
        __v = (Tcl_WideInt) _tmpVar_double_1;
        /******** makeSLUT_c 9: set mean [expr {(1.0*$max+$min)/2.0}] */
        /***** ::tsp::generate_set assign from command (set mean = _tmpVar_double_1) */
        /******** makeSLUT_c 9: expr {(1.0*$max+$min)/2.0} */
        exprErrMsg = NULL;
        _tmpVar_double_1 = TSP_func_double_div(((1.0 * __max) + __min), 2.0);
        if (exprErrMsg != NULL) {
            Tcl_ResetResult(interp);
            Tcl_AppendResult(interp, exprErrMsg, ", in proc: makeSLUT_c line: 9", (char*)NULL);
            *rc = TCL_ERROR;
            ERROR_EXIT;
        }
        /***** ::tsp::gen_assign_scalar_scalar */
        __mean = (double) _tmpVar_double_1;
        /******** makeSLUT_c 10: set span [expr {(1.0*$max-$min)}] */
        /***** ::tsp::generate_set assign from command (set span = _tmpVar_double_1) */
        /******** makeSLUT_c 10: expr {(1.0*$max-$min)} */
        _tmpVar_double_1 = ((1.0 * __max) - __min);
        /***** ::tsp::gen_assign_scalar_scalar */
        __span = (double) _tmpVar_double_1;
        /******** makeSLUT_c 11: set sv [expr {($v-$mean)/($span/10.0)}]; */
        /***** ::tsp::generate_set assign from command (set sv = _tmpVar_double_1) */
        /******** makeSLUT_c 11: expr {($v-$mean)/($span/10.0)} */
        exprErrMsg = NULL;
        _tmpVar_double_1 = TSP_func_double_div((__v - __mean), TSP_func_double_div(__span, 10.0));
        if (exprErrMsg != NULL) {
            Tcl_ResetResult(interp);
            Tcl_AppendResult(interp, exprErrMsg, ", in proc: makeSLUT_c line: 11", (char*)NULL);
            *rc = TCL_ERROR;
            ERROR_EXIT;
        }
        /***** ::tsp::gen_assign_scalar_scalar */
        __sv = (double) _tmpVar_double_1;
        /******** makeSLUT_c 12: set s [expr {1 / (1 + exp(-$sv))}]; */
        /***** ::tsp::generate_set assign from command (set s = _tmpVar_double_1) */
        /******** makeSLUT_c 12: expr {1 / (1 + exp(-$sv))} */
        exprErrMsg = NULL;
        _tmpVar_double_1 = TSP_func_double_div(1, (1 + TSP_func_exp((-(__sv)))));
        if (exprErrMsg != NULL) {
            Tcl_ResetResult(interp);
            Tcl_AppendResult(interp, exprErrMsg, ", in proc: makeSLUT_c line: 12", (char*)NULL);
            *rc = TCL_ERROR;
            ERROR_EXIT;
        }
        /***** ::tsp::gen_assign_scalar_scalar */
        __s = (double) _tmpVar_double_1;
        /******** makeSLUT_c 14: set vs [expr {$span*$s+$min}] */
        /***** ::tsp::generate_set assign from command (set vs = _tmpVar_double_1) */
        /******** makeSLUT_c 14: expr {$span*$s+$min} */
        _tmpVar_double_1 = ((__span * __s) + __min);
        /***** ::tsp::gen_assign_scalar_scalar */
        __vs = (double) _tmpVar_double_1;
        /******** makeSLUT_c 16: set ps [expr {abs(($i-128.0)/128)}] */
        /***** ::tsp::generate_set assign from command (set ps = _tmpVar_double_1) */
        /******** makeSLUT_c 16: expr {abs(($i-128.0)/128)} */
        exprErrMsg = NULL;
        _tmpVar_double_1 = TSP_func_double_abs(TSP_func_double_div((__i - 128.0), 128));
        if (exprErrMsg != NULL) {
            Tcl_ResetResult(interp);
            Tcl_AppendResult(interp, exprErrMsg, ", in proc: makeSLUT_c line: 16", (char*)NULL);
            *rc = TCL_ERROR;
            ERROR_EXIT;
        }
        /***** ::tsp::gen_assign_scalar_scalar */
        __ps = (double) _tmpVar_double_1;
        /******** makeSLUT_c 17: set vf [expr {round($v*(1-$ps)+$vs*$ps)}]; */
        /***** ::tsp::generate_set assign from command (set vf = _tmpVar_int_1) */
        /******** makeSLUT_c 17: expr {round($v*(1-$ps)+$vs*$ps)} */
        exprErrMsg = NULL;
        _tmpVar_int_1 = TSP_func_round(((__v * (1 - __ps)) + (__vs * __ps)));
        if (exprErrMsg != NULL) {
            Tcl_ResetResult(interp);
            Tcl_AppendResult(interp, exprErrMsg, ", in proc: makeSLUT_c line: 17", (char*)NULL);
            *rc = TCL_ERROR;
            ERROR_EXIT;
        }
        /***** ::tsp::gen_assign_scalar_scalar */
        __vf = (double) _tmpVar_int_1;
        /******** makeSLUT_c 19: lappend lut [expr {int($vf)}] */
        /***** ::tsp::gen_command_lappend */
        /* ::tsp::lang_dup_var_if_shared */
        if (__lut != NULL) {
            if (Tcl_IsShared(__lut)) {
                Tcl_DecrRefCount(__lut);
                __lut = Tcl_DuplicateObj(__lut);
                Tcl_IncrRefCount(__lut);
            }
        } else {
            __lut = Tcl_NewStringObj("",-1);
            Tcl_IncrRefCount(__lut);
        }
        /***** ::tsp::generate_set assign from command (set _tmpVar_var_1 = _tmpVar_int_1) */
        /******** makeSLUT_c 19: expr {int($vf)} */
        _tmpVar_int_1 = (TCL_WIDE_INT_TYPE)__vf;
        /***** ::tsp::gen_assign_scalar_scalar */
        /* ::tsp::lang_assign_var_int */
        _tmpVar_var_1 = TSP_Util_lang_assign_var_int(_tmpVar_var_1, (TCL_WIDE_INT_TYPE) _tmpVar_int_1);
        /* ::tsp::lang_lappend_var */
        Tcl_ListObjAppendElement(interp, __lut, _tmpVar_var_1);
        /* ::tsp::gen_command_for postloop */
        /******** makeSLUT_c 7: incr i */
        __i = __i + (1);
        /* evaluate condition */
        _tmpVar_boolean_1 = (__i < 256);
    }
    /******** makeSLUT_c 21: set clut [binary format c* $lut] */
    /***** ::tsp::generate_set assign from command (set clut = _tmpVar_cmdResultObj) */
    /******** makeSLUT_c 21: binary format c* $lut */
    /***** ::tsp::gen_direct_tcl binary */
    argObjvArray_1[0] = NULL;
    argObjvArray_1[1] = _constant_1;
    argObjvArray_1[2] = _constant_2;
    argObjvArray_1[3] = __lut;
    /*  ::tsp::lang_invoke_builtin */
    if ((*rc = (TSP_Cmd_builtin_binary) ((ClientData)NULL, interp,  4, argObjvArray_1)) != TCL_OK) {
        ERROR_EXIT;
    }
    if (_tmpVar_cmdResultObj != NULL) { Tcl_DecrRefCount(_tmpVar_cmdResultObj); _tmpVar_cmdResultObj = NULL; } 
    _tmpVar_cmdResultObj = Tcl_GetObjResult(interp);
    Tcl_IncrRefCount(_tmpVar_cmdResultObj);
    /***** ::tsp::gen_assign_scalar_scalar */
    /* ::tsp::lang_assign_var_var */
    __clut = TSP_Util_lang_assign_var_var(__clut, _tmpVar_cmdResultObj);
    /******** makeSLUT_c 22: return $clut */
    /***** ::tsp::gen_command_return */
    /***** ::tsp::gen_assign_scalar_scalar */
    /* ::tsp::lang_assign_var_var */
    _tmpVar_var_1 = TSP_Util_lang_assign_var_var(_tmpVar_var_1, __clut);
    Tcl_IncrRefCount(_tmpVar_var_1);
    /* ::tsp::lang_return */
    returnValue = _tmpVar_var_1;
    Tcl_IncrRefCount(returnValue);
    *rc = TCL_OK;
    CLEANUP;
    /* returnValue is cleaned up by calling proc */;
    return RETURN_VALUE;
    /* if void, then we can jump to normal_exit, if not-void, then that means the proc fell through */
    /* without returning a value.  in that case, set result and return error code*/
    Tcl_SetResult(interp, "end of proc encountered without 'return' command, proc type: var", TCL_STATIC); goto error_exit;    
  error_exit:
    *rc = TCL_ERROR;
  normal_exit:
    CLEANUP;
    RETURN_VALUE_CLEANUP;
    return RETURN_VALUE;
}
/* redefine macros for the Tcl interface function */
#undef CLEANUP
#undef RETURN_VALUE_CLEANUP
#undef RETURN_VALUE
#undef ERROR_EXIT
#define CLEANUP \

#define RETURN_VALUE_CLEANUP 
#define RETURN_VALUE 
#define ERROR_EXIT goto error_exit
/* 
 * Tcl command interface 
 *
 */
int makeSLUT_c(ClientData clientData, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]) {
    int _rc;
    int* rc = &_rc;;
    Tcl_Obj* returnValue = NULL;
    /* variables used by this command, assigned from objv array */
    double __gamma;
    double __min;
    double __max;
    double __offset;
    double __factor;
    /* allow other compiled procs to find the this proc function at runtime, see TSP_cmd.TSP_User_getCmd() */
    if (clientData != NULL && objc == 0) {
        void** cd = clientData;
        *cd = (void*) TSP_UserDirect_makeSLUT_c;
        return TCL_OK;
    }
    /* check arg count */
    if (objc != 6) {
        Tcl_WrongNumArgs(interp, 1, objv, "gamma min max offset factor");
        return TCL_ERROR;
    }
    /* assign arg variable from objv array */
    /* ::tsp::lang_convert_double_var */
    if ((*rc = Tcl_GetDoubleFromObj(interp, objv[1], &__gamma)) != TCL_OK) {
        Tcl_AppendResult(interp, "can't convert arg 1 to double", "objv[1]", (char *) NULL);
        ERROR_EXIT;
    }
    /* ::tsp::lang_convert_double_var */
    if ((*rc = Tcl_GetDoubleFromObj(interp, objv[2], &__min)) != TCL_OK) {
        Tcl_AppendResult(interp, "can't convert arg 2 to double", "objv[2]", (char *) NULL);
        ERROR_EXIT;
    }
    /* ::tsp::lang_convert_double_var */
    if ((*rc = Tcl_GetDoubleFromObj(interp, objv[3], &__max)) != TCL_OK) {
        Tcl_AppendResult(interp, "can't convert arg 3 to double", "objv[3]", (char *) NULL);
        ERROR_EXIT;
    }
    /* ::tsp::lang_convert_double_var */
    if ((*rc = Tcl_GetDoubleFromObj(interp, objv[4], &__offset)) != TCL_OK) {
        Tcl_AppendResult(interp, "can't convert arg 4 to double", "objv[4]", (char *) NULL);
        ERROR_EXIT;
    }
    /* ::tsp::lang_convert_double_var */
    if ((*rc = Tcl_GetDoubleFromObj(interp, objv[5], &__factor)) != TCL_OK) {
        Tcl_AppendResult(interp, "can't convert arg 5 to double", "objv[5]", (char *) NULL);
        ERROR_EXIT;
    }
    /* invoke compiled proc method */
    _rc = TCL_OK;
    returnValue = TSP_UserDirect_makeSLUT_c(interp, &_rc , __gamma, __min, __max, __offset, __factor);
    if (_rc == TCL_OK) {
        Tcl_SetObjResult(interp, returnValue);
        /* ok to fall through */
    }
  error_exit:
    CLEANUP;
    return _rc;
}
#ifndef DLLEXPORT 
#define DLLEXPORT __declspec(dllexport)
#endif
DLLEXPORT 
int Cimglib_Init(Tcl_Interp *interp) {
#ifdef USE_TCL_STUBS
  if (Tcl_InitStubs(interp, TCL_VERSION, 0) == 0L) {
    return TCL_ERROR;
  }
#endif
#ifdef USE_TK_STUBS
  if (Tk_InitStubs(interp, TCL_VERSION, 0) == 0L) {
    return TCL_ERROR;
  }
#endif
  Tcl_CreateObjCommand(interp, "::CImglib::CImg_testlut", tcl_CImg_testlut, NULL, NULL);
  Tcl_CreateObjCommand(interp, "::CImglib::CImg_import", tcl_CImg_import, NULL, NULL);
  Tcl_CreateObjCommand(interp, "::CImglib::CImg_export", tcl_CImg_export, NULL, NULL);
  Tcl_CreateObjCommand(interp, "::CImglib::CImg_width", tcl_CImg_width, NULL, NULL);
  Tcl_CreateObjCommand(interp, "::CImglib::CImg_height", tcl_CImg_height, NULL, NULL);
  Tcl_CreateObjCommand(interp, "::CImglib::CImg_pixel", tcl_CImg_pixel, NULL, NULL);
  Tcl_CreateObjCommand(interp, "::CImglib::CImg_iterate_kernel_int", tcl_CImg_iterate_kernel_int, NULL, NULL);
  Tcl_CreateObjCommand(interp, "::CImglib::CImg_iterate_channel", tcl_CImg_iterate_channel, NULL, NULL);
  Tcl_CreateObjCommand(interp, "::CImglib::CImg_mirror", tcl_CImg_mirror, NULL, NULL);
  Tcl_CreateObjCommand(interp, "::CImglib::CImg_fastreadjpg", tcl_CImg_fastreadjpg, NULL, NULL);
  Tcl_CreateObjCommand(interp, "::CImglib::CImg_imageResize", tcl_CImg_imageResize, NULL, NULL);
  Tcl_CreateObjCommand(interp, "::CImglib::CImg_rotate", tcl_CImg_rotate, NULL, NULL);
  Tcl_CreateObjCommand(interp, "::CImglib::CImg_fastscale", tcl_CImg_fastscale, NULL, NULL);
  Tcl_CreateObjCommand(interp, "::CImglib::CImg_loaded", tcl_CImg_loaded, NULL, NULL);
  Tcl_CreateObjCommand(interp, "::CImglib::makeLUT_cc", tcl_makeLUT_cc, NULL, NULL);
  Tcl_CreateObjCommand(interp, "::CImglib::makeLUT_c", makeLUT_c, NULL, NULL);
  Tcl_CreateObjCommand(interp, "::CImglib::makeSLUT_c", makeSLUT_c, NULL, NULL);
  Tcl_PkgProvide(interp, "CImgLib", "1.0");
  return(TCL_OK);
}

