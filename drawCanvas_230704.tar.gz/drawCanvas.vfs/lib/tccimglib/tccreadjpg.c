/*
 * example.c
 *
 * This file illustrates how to use the IJG code as a subroutine library
 * to read or write JPEG image files.  You should look at this code in
 * conjunction with the documentation file libjpeg.txt.
 *
 * This code will not do anything useful as-is, but it may be helpful as a
 * skeleton for constructing routines that call the JPEG library.  
 *
 * We present these routines in the same coding style used in the JPEG code
 * (ANSI function definitions, etc); but you are of course free to code your
 * routines in a different style if you prefer.
 */

#include <stdio.h>
#include <stdlib.h>
/*
 * Include file for users of JPEG library.
 * You will need to have included system headers that define at least
 * the typedefs FILE and size_t before you can include jpeglib.h.
 * (stdio.h is sufficient on ANSI-conforming systems.)
 * You may also wish to include "jerror.h".
 */

#include <jpeglib.h>

/*
 * <setjmp.h> is used for the optional error recovery mechanism shown in
 * the second part of the example.
 */

#include <setjmp.h>

/* Helper for Debugging*/
char __s[250];
char __buf2 [260];
Tcl_Interp *debug_interp; 
int vspfunc(char const *format, ...) {
    char __buf[250];
    
    va_list aptr;
    int ret;
    va_start(aptr, format);
    ret = vsprintf(__buf, format, aptr);
    va_end(aptr);
    sprintf(__buf2, "puts \"%s\"", __buf);
    
    return 1;
}


#define PUTS(msg) Tcl_Eval(debug_interp, "puts \""msg"\"");
#define PUTSV(msg,...) vspfunc(msg, __VA_ARGS__); Tcl_Eval(debug_interp,__buf2);

#define PUTV(msg,v) sprintf(__s, "puts \"%s: %d\"", msg,v);Tcl_Eval(debug_interp, __s);
#define PUTVS(msg,v) sprintf(__s, "puts \"%s: %s\"", msg,v);Tcl_Eval(debug_interp, __s);
const int exifMarker = JPEG_APP0 + 1;
static unsigned readUint16(JOCTET* data, boolean isBigEndian)
{
    if (isBigEndian)
        return (GETJOCTET(data[0]) << 8) | GETJOCTET(data[1]);
    return (GETJOCTET(data[1]) << 8) | GETJOCTET(data[0]);
}
static unsigned readUint32(JOCTET* data, boolean isBigEndian)
{
    if (isBigEndian)
        return (GETJOCTET(data[0]) << 24) | (GETJOCTET(data[1]) << 16) | (GETJOCTET(data[2]) << 8) | GETJOCTET(data[3]);
    return (GETJOCTET(data[3]) << 24) | (GETJOCTET(data[2]) << 16) | (GETJOCTET(data[1]) << 8) | GETJOCTET(data[0]);
}


static boolean checkExifHeader(jpeg_saved_marker_ptr marker, boolean *_isBigEndian, unsigned *_ifdOffset)
{
    // For exif data, the APP1 block is followed by 'E', 'x', 'i', 'f', '\0',
    // then a fill byte, and then a tiff file that contains the metadata.
    // A tiff file starts with 'I', 'I' (intel / little endian byte order) or
    // 'M', 'M' (motorola / big endian byte order), followed by (uint16_t)42,
    // followed by an uint32_t with the offset to the tag block, relative to the
    // tiff file start.
    //PUTV("Checking Exif Header",marker);
    const unsigned exifHeaderSize = 14;
    if (!(marker->marker == exifMarker
        && marker->data_length >= exifHeaderSize
        && marker->data[0] == 'E'
        && marker->data[1] == 'x'
        && marker->data[2] == 'i'
        && marker->data[3] == 'f'
        && marker->data[4] == '\0'
        // data[5] is a fill byte
        && ((marker->data[6] == 'I' && marker->data[7] == 'I')
            || (marker->data[6] == 'M' && marker->data[7] == 'M'))))
        return FALSE;
    boolean isBigEndian = marker->data[6] == 'M';
    if (readUint16(marker->data + 8, isBigEndian) != 42)
        return FALSE;
    unsigned ifdOffset = readUint32(marker->data + 10, isBigEndian);
    //PUTV("FOUND ifdOffset",ifdOffset);
    (*_isBigEndian)=isBigEndian;
    (*_ifdOffset)=ifdOffset;
    return TRUE;
};



static int readImageOrientation(struct jpeg_decompress_struct* info)
{
    // The JPEG decoder looks at EXIF metadata.
    // FIXME: Possibly implement XMP and IPTC support.
    //PUTS("Checking Exif for Orientation");
    //PUTV("Markerlist:",info->marker_list);
    const unsigned orientationTag = 0x112;
    const unsigned shortType = 3;
    for (jpeg_saved_marker_ptr marker = info->marker_list; marker; marker = marker->next) {
        boolean isBigEndian;
        unsigned ifdOffset;
        if (!checkExifHeader(marker, &isBigEndian, &ifdOffset))
            continue;
        //PUTV("Got Marker length",marker->data_length);
        //PUTV("Got ifdOffset",ifdOffset);
        const unsigned offsetToTiffData = 6; // Account for 'Exif\0<fill byte>' header.
        if (marker->data_length < offsetToTiffData || ifdOffset >= marker->data_length - offsetToTiffData)
            continue;
        //PUTS("Start reading EXIF");
        ifdOffset += offsetToTiffData;
        //PUTV("Got ifdOffset",ifdOffset);
        // The jpeg exif container format contains a tiff block for metadata.
        // A tiff image file directory (ifd) consists of a uint16_t describing
        // the number of ifd entries, followed by that many entries.
        // When touching this code, it's useful to look at the tiff spec:
        // http://partners.adobe.com/public/developer/en/tiff/TIFF6.pdf
        JOCTET* ifd = marker->data + ifdOffset;
        JOCTET* end = marker->data + marker->data_length;
        if (end - ifd < 2)
            continue;
        unsigned tagCount = readUint16(ifd, isBigEndian);
        ifd += 2; // Skip over the uint16 that was just read.
        // Every ifd entry is 2 bytes of tag, 2 bytes of contents datatype,
        // 4 bytes of number-of-elements, and 4 bytes of either offset to the
        // tag data, or if the data is small enough, the inlined data itself.
        const int ifdEntrySize = 12;
        //PUTV("tagCount",tagCount);
        for (unsigned i = 0; i < tagCount && end - ifd >= ifdEntrySize; ++i, ifd += ifdEntrySize) {
            unsigned tag = readUint16(ifd, isBigEndian);
            unsigned type = readUint16(ifd + 2, isBigEndian);
            unsigned count = readUint32(ifd + 4, isBigEndian);
            if (tag == orientationTag && type == shortType && count == 1)
                return (int)(readUint16(ifd + 8, isBigEndian));
        }
    }
    return -1;
}

/******************** JPEG COMPRESSION SAMPLE INTERFACE *******************/

/* This half of the example shows how to feed data into the JPEG compressor.
 * We present a minimal version that does not worry about refinements such
 * as error recovery (the JPEG code will just exit() if it gets an error).
 */


/*
 * IMAGE DATA FORMATS:
 *
 * The standard input image format is a rectangular array of pixels, with
 * each pixel having the same number of "component" values (color channels).
 * Each pixel row is an array of JSAMPLEs (which typically are unsigned chars).
 * If you are working with color data, then the color values for each pixel
 * must be adjacent in the row; for example, R,G,B,R,G,B,R,G,B,... for 24-bit
 * RGB color.
 *
 * For this example, we'll assume that this data structure matches the way
 * our application has stored the image in memory, so we can just pass a
 * pointer to our image buffer.  In particular, let's say that the image is
 * RGB color and is described by:
 */

//extern JSAMPLE * image_buffer;	/* Points to large array of R,G,B-order data */
//extern int image_height;	/* Number of rows in image */
//extern int image_width;		/* Number of columns in image */


/*
 * ERROR HANDLING:
 *
 * The JPEG library's standard error handler (jerror.c) is divided into
 * several "methods" which you can override individually.  This lets you
 * adjust the behavior without duplicating a lot of code, which you might
 * have to update with each future release.
 *
 * Our example here shows how to override the "error_exit" method so that
 * control is returned to the library's caller when a fatal error occurs,
 * rather than calling exit() as the standard error_exit method does.
 *
 * We use C's setjmp/longjmp facility to return control.  This means that the
 * routine which calls the JPEG library must first execute a setjmp() call to
 * establish the return point.  We want the replacement error_exit to do a
 * longjmp().  But we need to make the setjmp buffer accessible to the
 * error_exit routine.  To do this, we make a private extension of the
 * standard JPEG error handler object.  (If we were using C++, we'd say we
 * were making a subclass of the regular error handler.)
 *
 * Here's the extended error handler struct:
 */

struct my_error_mgr {
  struct jpeg_error_mgr pub;	/* "public" fields */

  jmp_buf setjmp_buffer;	/* for return to caller */
};

typedef struct my_error_mgr * my_error_ptr;

/*
 * Here's the routine that will replace the standard error_exit method:
 */

METHODDEF(void)
my_error_exit (j_common_ptr cinfo)
{
  /* cinfo->err really points to a my_error_mgr struct, so coerce pointer */
  my_error_ptr myerr = (my_error_ptr) cinfo->err;

  /* Always display the message. */
  /* We could postpone this until after returning, if we chose. */
  (*cinfo->err->output_message) (cinfo);

  /* Return control to the setjmp point */
  longjmp(myerr->setjmp_buffer, 1);
}


static int
tcc_jpgread_resize(
    Tcl_Interp *interp,		/* Interpreter to use for reporting errors. */
    char * filename,
    Tk_PhotoHandle imageHandle,	/* The photo image to write into. */
    int destX, int destY,	/* Coordinates of top-left pixel in
				 * photo image to be written to. */
    int width, int height,	/* Dimensions of block of photo image to
				 * be written to. */
    int srcX, int srcY		/* Coordinates of top-left pixel to be used
				 * in image being read. */
) {
 int scale, scalew, scaleh;
     char s[50];

  struct my_error_mgr jerr;
  /* More stuff */
  FILE * infile;		/* source file */
    struct jpeg_decompress_struct cinfo; 
    // j_decompress_ptr cinfo; 
    int fileWidth, fileHeight, stopY, curY, outY, outWidth, outHeight;
    int maxside, maxlen, denom;
    Tk_PhotoImageBlock block;
    JSAMPARRAY buffer;		/* Output row buffer */

    debug_interp=interp;
    
  if ((infile = fopen(filename, "rb")) == NULL) {
    PUTSV("can't open file %s", filename);
    return -1;
  }

  /* Step 1: allocate and initialize JPEG decompression object */

  /* We set up the normal JPEG error routines, then override error_exit. */
  cinfo.err = jpeg_std_error(&jerr.pub);
  jerr.pub.error_exit = my_error_exit;
  /* Establish the setjmp return context for my_error_exit to use. */
  if (setjmp(jerr.setjmp_buffer)) {
    /* If we get here, the JPEG code has signaled an error.
     * We need to clean up the JPEG object, close the input file, and return.
     */
    jpeg_destroy_decompress(&cinfo);
    fclose(infile);
    return -1;
  }
  /* Now we can initialize the JPEG decompression object. */
  jpeg_create_decompress(&cinfo);

  /* Step 2: specify data source (eg, a file) */

  jpeg_stdio_src(&cinfo, infile);

  /* Step 3: read file parameters with jpeg_read_header() */
    
    for (int m = 0; m < 16; m++)
     jpeg_save_markers(&cinfo, JPEG_APP0 + m, 0xFFFF);
    
    /* Ready to read header data. */
    jpeg_read_header(&cinfo, TRUE);

    /* This code only supports 8-bit-precision JPEG files. */
    if ((cinfo.data_precision != 8) ||
	    (sizeof(JSAMPLE) != sizeof(unsigned char))) {
        PUTS("Unsupported JPEG precision");
        return -1;
    }

    /* Process format parameters. */
    /* Select fast processing mode. */
    cinfo.two_pass_quantize =   FALSE;
    cinfo.dither_mode =         JDITHER_ORDERED;
    cinfo.dct_method =          JDCT_IFAST;
    cinfo.do_fancy_upsampling = FALSE;
    cinfo.do_block_smoothing=   FALSE;

    jpeg_calc_output_dimensions(&cinfo);
    /* Check dimensions. */
    fileWidth = (int) cinfo.output_width;
    fileHeight = (int) cinfo.output_height;

    /* calc resize denom */
    
    if(width>height) {
        maxlen=width;
    } else {
        maxlen=height;
    }
    if(fileWidth>fileHeight) {
        maxside=fileWidth;
    } else {
        maxside=fileHeight;
    }
    denom=maxside/maxlen;

   if      (denom > 8) denom = 8;
   else if (denom < 1) denom = 1;
    
    int p = 1;
    if(denom>0) {
        while (p <= denom) p *= 2;
        p=p/2;
    }
    if(p<1) p=1;
    if(p>8) p=8;
    
    /*sprintf(s, "maxlen %d maxside %d denom %d", maxlen, maxside, denom);
    sprintf(s, "scaling to p %d s %d", p, denom);*/
    //PUTSV("Rescaling image ... Denom is %d", denom);
    if(p>1) {
        // set denom to p
        cinfo.scale_num=1, 
        cinfo.scale_denom=p;
    }

    jpeg_calc_output_dimensions(&cinfo);
    fileWidth = (int) cinfo.output_width;
    fileHeight = (int) cinfo.output_height;
    
    //PUTS("calling exif orient");
    int orient= readImageOrientation(&cinfo);
    //PUTSV("Orientation %d",orient);
    jpeg_start_decompress(&cinfo);
    
	outWidth = fileWidth - srcX;
	outHeight = fileHeight - srcY;
    
    if ((outWidth <= 0) || (outHeight <= 0)
	|| (srcX >= fileWidth) || (srcY >= fileHeight)) {
	return -1;
    }

    /* Check colorspace. */
    switch (cinfo.out_color_space) {
    case JCS_GRAYSCALE:
	/* a single-sample grayscale pixel is expanded into equal R,G,B values */
	block.pixelSize = 1;
	block.offset[0] = 0;
	block.offset[1] = 0;
	block.offset[2] = 0;
	break;
    case JCS_RGB:
	/* note: this pixel layout assumes default configuration of libjpeg. */
	block.pixelSize = 3;
	block.offset[0] = 0;
	block.offset[1] = 1;
	block.offset[2] = 2;
	break;
    default:
        Tcl_Eval(interp, "puts \"Unsupported JPEG color space\"");
        return -1;
    }
    block.width = outWidth;
    block.height = outHeight;
    block.pitch = block.pixelSize * fileWidth;
    block.offset[3] = block.offset[0];


    /* Make a temporary one-row-high sample array */
    unsigned int w = cinfo.output_width;
    unsigned int h = cinfo.output_height;
    unsigned int numChannels = cinfo.num_components; // 3 = RGB, 4 = RGBA
    unsigned long dataSize = w * h * numChannels;
    
    // read RGB(A) scanlines one at a time into jdata[]
    unsigned char *data = (unsigned char *)malloc( dataSize );
    unsigned char* rowptr;
    while ( cinfo.output_scanline < h )
    {
        rowptr = data + cinfo.output_scanline * w * numChannels;
        jpeg_read_scanlines( &cinfo, &rowptr, 1 );
    }
    
    block.pixelPtr = data;
    
    if (Tk_PhotoExpand(interp, imageHandle, w, h) == TCL_ERROR) {
        jpeg_abort_decompress(&cinfo);
		return -1;
    }
    
    if (Tk_PhotoPutBlock(interp, imageHandle, &block, 0, 0, w, h, TK_PHOTO_COMPOSITE_SET) == TCL_ERROR) {
        jpeg_abort_decompress(&cinfo);
        return -1;
    }
    free(data);
    /* Do normal cleanup if we read the whole image; else early abort */
    if (cinfo.output_scanline == cinfo.output_height)
	jpeg_finish_decompress(&cinfo);
    else
	jpeg_abort_decompress(&cinfo);

  /* This is an important step since it will release a good deal of memory. */
  jpeg_destroy_decompress(&cinfo);

  /* After finish_decompress, we can close the input file.
   * Here we postpone it until after no more JPEG errors are possible,
   * so as to simplify the setjmp error logic above.  (Actually, I don't
   * think that jpeg_destroy can do an error exit, but why assume anything...)
   */
  fclose(infile);

  /* At this point you may want to check to see whether any corrupt-data
   * warnings occurred (test whether jerr.pub.num_warnings is nonzero).
   */

  /* And we're done! */
  //PUTV("Orientation in Exif",orient);
  return orient;
} 









