#ifndef TCC_HALDCLUT_H
#define TCC_HALDCLUT_H

/*
    var lutX = (b % 8) * 64 + r;
    var lutY = Math.floor(b / 8) * 64 + g;
*/
#define size2dim(size) (floor(sqrt(pow((size*size),1.0/3.0))+0.5))
#define lutV(v0,dim) (v0*dim*dim/256)
#define lutFX(r,g,b,dim) ((b%dim)*dim*dim+r)
#define lutFY(r,g,b,dim) (floor(b/dim)*dim*dim+g)
#define lutX(r,g,b,dim) (lutFX(lutV(r,dim),lutV(g,dim),lutV(b,dim),dim))
#define lutY(r,g,b,dim) (lutFY(lutV(r,dim),lutV(g,dim),lutV(b,dim),dim))
#endif /* TCC_HALDCLUT_H */
