/*
tcc_image manipulation routines exported
*/

#include <tcl.h>
#include "tccimage.h"

/* auxiliary routines */

static Tcl_Obj* tccimg_import(Tcl_Interp* interp, char* im1) {

    crimp_image* c_img;
    Tcl_Obj* tcl_img;
    Tk_PhotoHandle h1;
    struct Tk_PhotoImageBlock b1;
    int row, off1, off2;
    int rowsize,datasize;

    
    
    h1 = Tk_FindPhoto(interp,im1);
    if (h1 == NULL) {
        Tcl_SetResult(interp, "image handle not found", TCL_STATIC);
        return NULL;
    }
    Tk_PhotoGetImage(h1,&b1);
    if (b1.pixelSize != 4 ||
        b1.pitch     != (4 * b1.width) ||
        b1.offset[0] != 0 ||
        b1.offset[1] != 1 ||
        b1.offset[2] != 2 ||
        b1.offset[3] != 3) {
        Tcl_SetResult(interp, "unsupported image format", TCL_STATIC);
        return NULL;
    }    
    rowsize = b1.width * b1.pixelSize;
    datasize = b1.height * rowsize;

    c_img=crimp_new4(b1.width, b1.height);
    memcpy(c_img->pixel, b1.pixelPtr, datasize);
    
    tcl_img=crimp_new_image_obj(c_img);
    return tcl_img;    
}

static int tccimg_export(Tcl_Interp* interp, Tcl_Obj* imageObj, char* im1) {
    Tcl_Obj* tcl_img;
    crimp_image* c_img;
    Tk_PhotoHandle handle;
    struct Tk_PhotoImageBlock pib;
    int row, off1, off2;
    int rowsize,datasize;
    
    handle = Tk_FindPhoto(interp,im1);
    if (handle == NULL) {
         Tcl_SetResult(interp, "image handle not found", TCL_STATIC);
        return TCL_ERROR;
    }
    if (imageObj->typePtr != &ImageType) {
         Tcl_SetResult(interp, "wrong image format", TCL_STATIC);
	    return TCL_ERROR;
    }
    /* get image data */
    int       objc;
    Tcl_Obj **objv;
    unsigned char* bytes;
    int w, h, bl, length;
    crimp_pixel_array pixel;
    crimp_image* ci;
    Tcl_Obj* meta;
    crimp_image *image = (crimp_image*) imageObj->internalRep.otherValuePtr;
        
    /*
     * Fill the Tk image block to match our structure.
     */
    
    pib.pixelPtr  = image->pixel;
    pib.width     = image->w;
    pib.height    = image->h;
    pib.pixelSize = image->blen;
    pib.pitch     = image->blen * pib.width;
    pib.offset[0] = 0;
    pib.offset[1] = 1;
    pib.offset[2] = 2;
    pib.offset[3] = 3;
    
    /*
     * ... and push into the destination tk photo
     */
    
    if (Tk_PhotoSetSize (interp, handle, pib.width, pib.height) != TCL_OK ||
        Tk_PhotoPutBlock(interp, handle, &pib, 0, 0, pib.width, pib.height,
                         TK_PHOTO_COMPOSITE_SET) != TCL_OK) {
        return TCL_ERROR;
    }
    
    return TCL_OK;
}

static int tccimg_width(Tcl_Obj* imageObj) {

    /**/
    if (imageObj->typePtr != &ImageType) {
	    return TCL_ERROR;
    }

    crimp_image *image = (crimp_image*) imageObj->internalRep.otherValuePtr;
    return crimp_w (image);
}

static int tccimg_height(Tcl_Obj* imageObj) {

    /**/
    if (imageObj->typePtr != &ImageType) {
	    return TCL_ERROR;
    }

    crimp_image *image = (crimp_image*) imageObj->internalRep.otherValuePtr;
    return crimp_h (image);
}

static Tcl_Obj* tccimg_pixel(Tcl_Obj* imageObj) {

    /**/
    unsigned char* bytes;
    int            length;
    if (imageObj->typePtr != &ImageType) {
	    return NULL;
    }

    crimp_image *image = (crimp_image*) imageObj->internalRep.otherValuePtr;
    
    bytes  = image->pixel;
    length = crimp_image_area(image) * image->blen;
    
    return Tcl_NewByteArrayObj (bytes, length);
}

/* manipulation routines */

static int tccimg_iterate_kernel_int (Tcl_Interp* interp, Tcl_Obj* imageObj, Tcl_Obj* kernelobj, int kernelsize, double coeff, double linG) {
    /**/
    
    /*Tcl_Eval(interp, "puts \"iterating kernel int\"");*/
    
    int            length;
    
    int k_size,k_len;
    signed char* kernel;
    signed char kcr,kcg,kcb;
    double kcor,kcog,kcob;
    int x,y,b,kx,ky,kb,ix,iy,ib,kd;
    int v0,v1,v2;
    int r0,g0,b0;
    int ri,gi,bi;
    int sumr, sumb,sumg;
    float rf, gf, bf;
    int r1,g1,b1;
    int mx,my;
    
    int cpos;
    crimp_image* resultimage;
    
    if (imageObj->typePtr != &ImageType) {
        Tcl_Eval(interp, "puts \"Error: No valid image!\"");  
	    return TCL_ERROR;
    }

    crimp_image *image = (crimp_image*) imageObj->internalRep.otherValuePtr;
    
    length = crimp_image_area(image) * image->blen;
    
    k_size=kernelsize; kd=(int) k_size/2;
    k_len=k_size*3;
    if(k_size>10) {
        /* Error, bigger than k_buf*/
        return TCL_ERROR;
    }
    kernel=Tcl_GetByteArrayFromObj(kernelobj,&k_len);
    resultimage= crimp_dup (image);
    
    cpos=0;
    mx=crimp_w(image);my=crimp_h(image);
    for(y=0;y<my;y++) {
        for(x=0;x<mx;x++) {
            /**/
            sumr=0;sumg=0;sumb=0; kb=0;
            for (ky=0;ky<k_size;ky++) {
                iy=y+ky-kd;
                for (kx=0;kx<k_size;kx++) {
                    ix=x+kx-kd;
                    
                    /* get kernel coeff*/
                    kcr=kernel[kb]; 
                    
                    if(ix<0) ix=0; else if(ix>=mx) ix=mx-1; 
                    if(iy<0) iy=0; else if(iy>=my) iy=my-1;
                    
                    ri=R(image,ix,iy)*kcr;
                    gi=G(image,ix,iy)*kcr;
                    bi=B(image,ix,iy)*kcr;
                    
                    sumr=sumr+ri;
                    sumg=sumg+gi;
                    sumb=sumb+bi;
                    kb++;
                }
            }
            
            /*
            unsigned char bit8=(sumr&&64);
            sumr= (sumr >> 7)+(bit8>0);
            bit8=(sumg&&64);
            sumg= (sumg >> 7)+(bit8>0);
            bit8=(sumb&&64);
            sumb= (sumb >> 7)+(bit8>0);
            */
            
            rf=(float)sumr*coeff+linG; 
            gf=(float)sumg*coeff+linG; 
            bf=(float)sumb*coeff+linG;
            
            if(rf>255) rf=255;
            if(gf>255) gf=255;
            if(bf>255) bf=255;
            if(rf<0) rf=0;
            if(gf<0) gf=0;
            if(bf<0) bf=0;

            /*
            r1=(unsigned char) rf;
            g1=(unsigned char) gf;
            b1=(unsigned char) bf;
            */
            
            R(resultimage,x,y)=(unsigned char) rf;
            G(resultimage,x,y)=(unsigned char) gf;;
            B(resultimage,x,y)=(unsigned char) bf;

            cpos+=image->blen;
            if(cpos>length) {
                return TCL_ERROR;
            }
        }
    }
    imageObj->internalRep.otherValuePtr=resultimage;
    crimp_del(image);
    return TCL_OK;
}

static int tccimg_iterate_channel(Tcl_Interp* interp, Tcl_Obj* imageObj, Tcl_Obj* lutObj, int chanoffset, double coeff, double linG) {

    Tcl_Eval(interp, "puts \"iterating channel with lut\"");    
    
    int            length;
    char* lut;
    int k_size,k_len;
    int x,y,b,kx,ky,kb,ix,iy,ib,kd;
    int v0,v1,v2;
    int r0,g0,b0;
    unsigned char ri,gi,bi;
    int r1,g1,b1,sumi;
    float rf, gf, bf;
    double saturation, sumf;
    int mx,my;
    int cpos;
    crimp_image* resultimage;
    
    if (imageObj->typePtr != &ImageType) {
        Tcl_Eval(interp, "puts \"Error: No valid image!\"");  
	    return TCL_ERROR;
    }
    
    crimp_image *image = (crimp_image*) imageObj->internalRep.otherValuePtr;
    
    length = crimp_image_area(image) * image->blen;
    k_len=256;
    saturation=1.0;
    switch(chanoffset) {
        case 128: k_len=256*3; break;
        case 253: saturation=coeff; coeff=1.0; break;
        default: k_len=256; break;
    }
    lut=Tcl_GetByteArrayFromObj(lutObj,&k_len);
    resultimage= crimp_dup (image);
    
    cpos=0;
    mx=crimp_w(image);my=crimp_h(image);
    for(y=0;y<my;y++) {
        for(x=0;x<mx;x++) {
            
            r0=R(image,x,y);
            g0=G(image,x,y);
            b0=B(image,x,y);
            ri=r0;gi=g0;bi=b0;
            switch(chanoffset) {
                case 0: ri=lut[r0];gi=lut[g0];bi=lut[b0];break;
                case 1: ri=lut[r0]; break;
                case 2: gi=lut[g0]; break;
                case 3: bi=lut[b0]; break;
                case 128:
                    /* per channel LUT*/
                    ri=lut[r0];gi=lut[g0+256];bi=lut[b0+512];break;
                case 253:
                    /* perceptive gray and saturation by coeff*/
                    ri=lut[r0];gi=lut[g0];bi=lut[b0];
                    sumf = 0.2989*r0 + 0.5870*g0 + 0.1140*b0;
                    if(sumf>255) sumf=255; else if(sumf<0) sumf=0;
                    rf= -sumf * saturation + (float)ri * (1.0+saturation);
                    gf= -sumf * saturation + (float)gi * (1.0+saturation);
                    bf= -sumf * saturation + (float)bi * (1.0+saturation);
                    break;                    
                case 254:
                    /* perceptive gray */
                    sumi = 0.2989*r0 + 0.5870*g0 + 0.1140*b0;
                    if(sumi>255) sumi=255; else if(sumi<0) sumi=0;
                    ri=lut[sumi];gi=lut[sumi];bi=lut[sumi];
                    break;                    
                case 255: 
                    /* luminant gray */
                    sumi=(ri+gi+bi)/3;
                    if(sumi>255) sumi=255; else if(sumi<0) sumi=0;
                    ri=lut[sumi];gi=lut[sumi];bi=lut[sumi];
                    break;
                default:  break;
            }
            /* linear operations*/
            switch(chanoffset) {
                case 253: break;
                default: 
                    rf=(float)ri*coeff+linG; 
                    gf=(float)gi*coeff+linG; 
                    bf=(float)bi*coeff+linG;
                    break;
            }
            
            if(rf>255) rf=255;
            if(gf>255) gf=255;
            if(bf>255) bf=255;
            if(rf<0) rf=0;
            if(gf<0) gf=0;
            if(bf<0) bf=0;

            R(resultimage,x,y)=(unsigned char) rf;
            G(resultimage,x,y)=(unsigned char) gf;
            B(resultimage,x,y)=(unsigned char) bf;

            cpos+=image->blen;
            if(cpos>length) {
                Tcl_Eval(interp, "puts \"out of pixels???\"");    
                return TCL_ERROR;
            }
        }
    }

    imageObj->internalRep.otherValuePtr=resultimage;
    crimp_del(image);
    return TCL_OK;
}

static int tccimg_rotate (Tcl_Interp* interp, Tcl_Obj* imageObj, int direction) {
    /**/
    // direction 0 n 1 l 2 u 3 r 
    Tcl_Eval(interp, "puts \"rotating image\"");
    
    int            length, width, height;
    int x,y,mx,my, tx,ty,nx,ny, cpos;
    int r0,g0,b0;
    
    crimp_image* resultimage;
    
    if (imageObj->typePtr != &ImageType) {
        Tcl_Eval(interp, "puts \"Error: No valid image!\"");  
	    return TCL_ERROR;
    }

    crimp_image *image = (crimp_image*) imageObj->internalRep.otherValuePtr;
    length = crimp_image_area(image) * image->blen;
    mx=crimp_w(image);my=crimp_h(image);
    
    if(direction==0) {nx=mx;ny=my;}
    if(direction==1) {nx=my;ny=mx;}
    if(direction==2) {nx=mx;ny=my;}
    if(direction==3) {nx=my;ny=mx;}
    resultimage= crimp_new (nx,ny);
    cpos=0;
   
    for(y=0;y<my;y++) {
        if(direction==0) {ty=y;}
        if(direction==1) {tx=y;}
        if(direction==2) {ty=my-y-1;}
        if(direction==3) {tx=my-y-1;}
        for(x=0;x<mx;x++) {
            r0=R(image,x,y);
            g0=G(image,x,y);
            b0=B(image,x,y);
            if(direction==0) {tx=x;}
            if(direction==1) {ty=mx-x-1;}
            if(direction==2) {tx=mx-x-1;}
            if(direction==3) {ty=x;}
            R(resultimage,tx,ty)=(unsigned char)r0;
            G(resultimage,tx,ty)=(unsigned char)g0;
            B(resultimage,tx,ty)=(unsigned char)b0;
            cpos+=image->blen;
            if(cpos>length) {
                return TCL_ERROR;
            }
        }
    }
    Tcl_InvalidateStringRep(imageObj);
    imageObj->internalRep.otherValuePtr=resultimage;
    crimp_del(image);
    return TCL_OK;
}

/* https://wiki.tcl-lang.org/page/Image+Scaling+in+C */
/* scaler is usually 2.0 and can be set to 4 or 8 to speed up / loose quality :-) */

static int tccimg_fastscale(
  Tcl_Interp *interp,
  char* srcName, 
  char* destName,
  int newwid,
  int newhgt,
  int scaler  
){
    Tk_PhotoImageBlock srcBlock, destBlock;
    Tk_PhotoHandle srcImage, destImage;
    int di, dj;
    double scalex, scaley, sx2, sy2, newalpha;
    int returnCode;
    int width, height;

    newalpha=1.0;

    srcImage = Tk_FindPhoto(interp, srcName);
    if (!srcImage)
        return TCL_ERROR;
    Tk_PhotoGetSize(srcImage, &width, &height);
    Tk_PhotoGetImage(srcImage, &srcBlock);

    if (!srcBlock.pixelPtr) {
        /* Empty image. Do nothing */
        return TCL_OK;
    }

    if (srcBlock.pixelSize != 4 && srcBlock.pixelSize!=3) {
        Tcl_AppendResult(interp, "I can't make heads or tails from this image, the bitfield is neither 3 nor 4", NULL);
        return TCL_ERROR;
    }

    destImage = Tk_FindPhoto(interp, destName);
    if (!destImage)
        return TCL_ERROR;
    Tk_PhotoBlank(destImage);
    Tk_PhotoSetSize(interp, destImage, newwid, newhgt);    

    destBlock.width = newwid;
    destBlock.height = newhgt;
    
    scalex = srcBlock.width / (double) newwid;
    scaley = srcBlock.height / (double) newhgt;
    sx2 = scalex / (double) scaler; // 2.0
    sy2 = scaley / (double) scaler;

    destBlock.pixelSize = 4;
    destBlock.pitch = newwid * 4;
    destBlock.offset[0] = 0; 
    destBlock.offset[1] = 1; 
    destBlock.offset[2] = 2; 
    destBlock.offset[3] = 3;
    destBlock.pixelPtr = (unsigned char *) Tcl_Alloc(destBlock.width * destBlock.height * 4);

    /* Loop through and scale */
    for (dj=0 ; dj<destBlock.height ; dj++) {
        for (di=0 ; di<destBlock.width ; di++) {
            int si, sj;
            int cx = (int)(di * scalex);
            int cy = (int)(dj * scaley);
            int points = 1;
            double red = 0.0, green = 0.0, blue = 0.0, alpha = 0.0;
            int newoff = destBlock.pitch*dj + destBlock.pixelSize*di;
            int startoff = srcBlock.pitch*cy + srcBlock.pixelSize*cx;

            red = (double) srcBlock.pixelPtr[startoff + srcBlock.offset[0]];
            green = (double) srcBlock.pixelPtr[startoff + srcBlock.offset[1]];
            blue = (double) srcBlock.pixelPtr[startoff + srcBlock.offset[2]];
            if (srcBlock.pixelSize == 4) {
                alpha = (double) srcBlock.pixelPtr[startoff + srcBlock.offset[3]];
            } else {
                alpha += 255;
            }
            for (sj=(int)cy-sy2 ; sj<(int)cy+sy2 ; sj++) {
                if (sj < 0)
                    continue;
                if (sj > srcBlock.height)
                    continue;
                for (si=(int)cx-sx2 ; si<(int)cx+sx2 ; si++) {
                    int offset = srcBlock.pitch*sj + srcBlock.pixelSize*si;
                    if (si < 0)
                        continue;
                    if (si > srcBlock.width)
                        continue;

                    points++;
                    red += (double) srcBlock.pixelPtr[offset + srcBlock.offset[0]];
                    green += (double) srcBlock.pixelPtr[offset + srcBlock.offset[1]];
                    blue += (double) srcBlock.pixelPtr[offset + srcBlock.offset[2]];
                    if (srcBlock.pixelSize == 4) {
                        alpha += (double) srcBlock.pixelPtr[offset + srcBlock.offset[3]];
                    } else {
                        alpha += 255;
                    }
                }
            }
            destBlock.pixelPtr[newoff + destBlock.offset[0]] = (unsigned char)(red / points);
            destBlock.pixelPtr[newoff + destBlock.offset[1]] = (unsigned char)(green / points);
            destBlock.pixelPtr[newoff + destBlock.offset[2]] = (unsigned char)(blue / points);
            destBlock.pixelPtr[newoff + destBlock.offset[3]] = (unsigned char)(alpha / points);
        }
    }
    returnCode = Tk_PhotoPutBlock(interp, destImage, &destBlock, 0, 0,
            destBlock.width, destBlock.height, TK_PHOTO_COMPOSITE_SET);
    Tcl_Free(destBlock.pixelPtr);
    return returnCode;
}



/* ---------------------------------------------------------------------
 *
 *  ScalePhotoBlock --
 *
 *      Scales a photo block. blockPtr is modified to hold new photo
 *      block information.
 *      On success, once the block is used (passed to Tk_PhotoPutBlock()),
 *      blockPtr->pixelPtr must be freed.
 *      Ported from PBM by Eric Boudaillier http://wiki.tcl.tk/10504
 *      Tom Wilkason wrapped it into a TCL command
 * ---------------------------------------------------------------------
 */
int
  ScalePhotoBlock (
                  Tcl_Interp *interp,
                  Tk_PhotoImageBlock *srcBlockPtr,
                  Tk_PhotoImageBlock *dstBlockPtr,
                  int newcols,
                  int newrows)
{
#define SCALE      4096
#define HALFSCALE  2048
#define MAXPIXVAL  255
   unsigned char *xelrow;
   unsigned char *tempxelrow;
   unsigned char *newimage;
   unsigned char *newxelrow;
   register unsigned char *xP;
   register unsigned char *nxP;
   int rows, cols, srcrow, bpp;
   register int row, col, needtoreadrow, p;
   double xscale, yscale;
   long   sxscale, syscale;
   register long fracrowtofill, fracrowleft;
   long  *pixarray[4], v;
   int pitch, newpitch;

   cols    = srcBlockPtr->width;
   rows    = srcBlockPtr->height;
   bpp     = srcBlockPtr->pixelSize;
   xscale = (double) newcols / cols;
   yscale = (double) newrows / rows;
   sxscale = (long) (xscale * SCALE);
   syscale = (long) (yscale * SCALE);

   pitch = srcBlockPtr->pitch;
   newpitch = newcols*bpp;

   if (newrows != rows)
   {
      tempxelrow = (unsigned char*) Tcl_AttemptAlloc(bpp*cols);
      if (!tempxelrow)
      {
         Tcl_SetResult(interp, "memory allocation failed", TCL_STATIC);
         return TCL_ERROR;
      }
   } else
   {
      tempxelrow = 0;
   }
   pixarray[0] = (long*) Tcl_AttemptAlloc(bpp*cols*sizeof(long));
   if (!pixarray[0])
   {
      if (tempxelrow)
         Tcl_Free((char*) tempxelrow);
      Tcl_SetResult(interp, "memory allocation failed", TCL_STATIC);
      return TCL_ERROR;
   }
   pixarray[1] = pixarray[0] + cols;
   pixarray[2] = pixarray[1] + cols;
   pixarray[3] = pixarray[2] + cols;
   for (p = 0; p < bpp; ++p)
   {
      for (col = 0; col < cols; ++col)
         pixarray[p][col] = HALFSCALE;
   }

   fracrowleft   = syscale;
   needtoreadrow = 1;
   fracrowtofill = SCALE;

   newimage = (unsigned char*) Tcl_AttemptAlloc(newcols * newrows * bpp);
   if (!newimage)
   {
      if (newrows != rows)
         Tcl_Free((char*) tempxelrow);
      Tcl_Free((char*) pixarray[0]);
      Tcl_SetResult(interp, "couldn't allocate image", TCL_STATIC);
      return TCL_ERROR;
   }
   newxelrow = newimage;
   xelrow = 0;
   for (row = 0, srcrow = 0; row < newrows; ++row)
   {
        /* First scale Y from xelrow into tempxelrow. */
      if (newrows == rows)  /* shortcut Y scaling if possible */
      {
         tempxelrow = xelrow = srcBlockPtr->pixelPtr + (pitch * srcrow++);
      } else
      {
         while (fracrowleft < fracrowtofill)
         {
            if (needtoreadrow && srcrow < rows)
               xelrow = srcBlockPtr->pixelPtr + (pitch * srcrow++);
            for (col = 0, xP = xelrow; col < cols; ++col)
               for (p = 0; p < bpp; ++p, ++xP)
                  pixarray[p][col] += fracrowleft * *xP;
            fracrowtofill -= fracrowleft;
            fracrowleft = syscale;
            needtoreadrow = 1;
         }

            /* Now fracrowleft is >= fracrowtofill, so we can produce a row. */
         if (needtoreadrow && srcrow < rows)
         {
            xelrow = srcBlockPtr->pixelPtr + (pitch * srcrow++);
            needtoreadrow = 0;
         }
         for (col = 0, xP = xelrow, nxP = tempxelrow; col < cols; ++col)
         {
            for (p = 0; p < bpp; ++p, ++xP, ++nxP)
            {
               v = (pixarray[p][col] + fracrowtofill * *xP) / SCALE;
               *nxP = (unsigned char) (v > MAXPIXVAL ? MAXPIXVAL:v);
               pixarray[p][col] = HALFSCALE;
            }
         }
         fracrowleft -= fracrowtofill;
         if (fracrowleft == 0)
         {
            fracrowleft = syscale;
            needtoreadrow = 1;
         }
         fracrowtofill = SCALE;
      }


        /* Now scale X from tempxelrow into newxelrow and write it out. */
      if (newcols == cols)  /* shortcut X scaling if possible */
      {
         for (col = 0, xP = tempxelrow, nxP = newxelrow; col < cols; ++col)
            for (p = 0; p < bpp; ++p, ++xP, ++nxP)
               *nxP = *xP;
         newxelrow = newxelrow + newpitch;
      } else
      {
         long pixval[4];
         register long fraccoltofill, fraccolleft;
         register int needcol;

         nxP = newxelrow;
         fraccoltofill = SCALE;
         for (p = 0; p < bpp; ++p)
            pixval[p] = HALFSCALE;
         needcol = 0;
         for (col = 0, xP = tempxelrow; col < cols; ++col, xP += bpp)
         {
            fraccolleft = sxscale;
            while (fraccolleft >= fraccoltofill)
            {
               if (needcol)
               {
                  nxP += bpp;
                  for (p = 0; p < bpp; ++p)
                     pixval[p] = HALFSCALE;
               }
               for (p = 0; p < bpp; ++p)
               {
                  pixval[p] = (pixval[p] + fraccoltofill * xP[p]) / SCALE;
                  if (pixval[p] > MAXPIXVAL) pixval[p] = MAXPIXVAL;
                  nxP[p]    = (unsigned char) pixval[p];
               }
               fraccolleft  -= fraccoltofill;
               fraccoltofill = SCALE;
               needcol = 1;
            }
            if (fraccolleft > 0)
            {
               if (needcol)
               {
                  nxP += bpp;
                  for (p = 0; p < bpp; ++p)
                     pixval[p] = HALFSCALE;
                  needcol = 0;
               }
               for (p = 0; p < bpp; ++p)
                  pixval[p] += fraccolleft * xP[p];
               fraccoltofill -= fraccolleft;
            }
         }
         if (fraccoltofill > 0)
         {
            xP -= bpp;
            for (p = 0; p < bpp; ++p)
               pixval[p] += fraccoltofill * xP[p];
         }
         if (!needcol)
         {
            for (p = 0; p < bpp; ++p)
            {
               pixval[p] /= SCALE;
               if (pixval[p] > MAXPIXVAL) pixval[p] = MAXPIXVAL;
               nxP[p] = (unsigned char) pixval[p];
            }
         }
         newxelrow = newxelrow + newpitch;
      }
   }

   Tcl_Free((char*) pixarray[0]);
   if (newrows != rows)
      Tcl_Free((char*) tempxelrow);

   dstBlockPtr->width = newcols;
   dstBlockPtr->height = newrows;
   dstBlockPtr->pixelSize = bpp;
   dstBlockPtr->pitch = newpitch;
   dstBlockPtr->pixelPtr = newimage;
   dstBlockPtr->offset[0] = 0;
   dstBlockPtr->offset[1] = 1;
   dstBlockPtr->offset[2] = 2;
   dstBlockPtr->offset[3] = 3;

   return TCL_OK;

#undef SCALE
#undef HALFSCALE
#undef MAXPIXVAL
}

/*----------------------------------------------------------------------*
 * Tcl/Tk imageResize command
 *
 *   Usage: image src dest xscale yscale
 *   Tom Wilkason
 #   with tcc this is 3x slower than precompiled with a real compiler... sigh!
 *----------------------------------------------------------------------*/
static int
  tccimg_imageResize
  (
  Tcl_Interp *interp,
  char* src,
  char* dest,
  int newrows,
  int newcols
  )
{

   int result;
   Tk_PhotoHandle sp, dp;
   Tk_PhotoImageBlock sb, db;
   /* Get images */
   sp = Tk_FindPhoto(interp, src );
   dp = Tk_FindPhoto(interp, dest);
   if (sp==0)
   {
      Tcl_AppendResult (interp, "Invalid image source specified",NULL);
      return TCL_ERROR;
   } else if (dp==0)
   {
      Tcl_AppendResult (interp, "Invalid image destination specified",NULL);
      return TCL_ERROR;
   }
   db.pixelPtr = 0;
   Tk_PhotoGetImage(sp, &sb);
   Tk_PhotoGetImage(dp, &db);
   result = ScalePhotoBlock(interp,&sb,&db,newrows,newcols);
   if (result == TCL_OK)
   {
      /* void under 8.3 not 8.4? */
      /*
         The compRule parameter to Tk_PhotoPutBlock specifies a compositing rule
         that says what to do with transparent pixels.  The value
         TK_PHOTO_COMPOSITE_OVERLAY says that the previous contents of the photo
         image should show through, and the value TK_PHOTO_COMPOSITE_SET says that
         the previous contents of the photo image should be completely ignored, and
         the values from the block be copied directly across.  The behavior in
         Tk8.3 and earlier was equivalent to having TK_PHOTO_COMPOSITE_OVERLAY as a
         compositing rule.
      */
      Tk_PhotoPutBlock(interp, dp, &db,0, 0, newrows, newcols,TK_PHOTO_COMPOSITE_SET);
      if (db.pixelPtr)
      {
         Tcl_Free((char *)db.pixelPtr);
      }
      /*
      if (result != TCL_OK)
      {
         Tcl_AppendResult (interp, "Error putting image data into destination",NULL);
         return TCL_ERROR;
      }
      */
      return TCL_OK;
   } else {
      return result;
   }
}

